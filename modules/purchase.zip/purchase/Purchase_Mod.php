<?php

/**
 * Description of Purchase_Mod
 *
 * @author psmahadevan
 */
class Purchase_Mod {

    private $crg;
    private $ses;
    private $db;
    private $sd;
    private $tpl;
    private $rbac;

    public function __construct($reg = NULL) {
        /*
         * Receiving $rg array
         */
        $this->crg = $reg;

        /*
         * geting object from reg array
         */
        $this->ses = $this->crg->get('ses');
        $this->db = $this->crg->get('db');
        $this->sd = $this->crg->get('SD');
        $this->tpl = $this->crg->get('tpl');
        $this->rbac = $this->crg->get('rbac');
    }

////////////////////// Purchase_Indent_Form ////////
    
function manage(){
     
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            /////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///////////
            /////////////////////////////////////////////////////////////////
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
            
            include_once 'util/genUtil.php';
            $util = new GenUtil();
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            $username=$this->ses->get('user')['user_nicename'];
            $this->tpl->set('preparedby', $username);
            $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
            $unit_table = $this->crg->get('table_prefix') . 'unit';
            $indent_detail_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
            $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
            $user_table = $this->crg->get('table_prefix') . 'users';
            $approvaltype_tab = $this->crg->get('table_prefix') . 'approvaltype';
            $approvalprocess_tab = $this->crg->get('table_prefix') . 'approvalprocess';
            
            //rawmaterial table data
           
            $sql = "SELECT ID,RMName FROM $rawmaterial_table";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $rawmaterial_data  = $stmt->fetchAll();	
            $this->tpl->set('rawmaterial_data', $rawmaterial_data);
            
            //unit table data
           
            $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
            
            $sql = "SELECT approver_ID FROM $approvaltype_tab where $approvaltype_tab.ProcessTypeName='Purchase Indent'"; 
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $approvaltype_data = $stmt->fetchAll();	
            $approve=$approvaltype_data;
           
            $sql = "SELECT $user_table.ID,$user_table.user_nicename FROM $user_table,$approvaltype_tab where $user_table.ID=$approvaltype_tab.approver_ID AND $approvaltype_tab.ProcessTypeName='Purchase Indent'"; 
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $approver_data = $stmt->fetchAll();	
            $this->tpl->set('approver_data', $approver_data);
           
        
            $this->tpl->set('page_title', 'Purchase Indent');	          
            $this->tpl->set('page_header', 'Production');
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }
            //Confirm Submit
             if (!empty($_POST['confirm_submit_button']) && $_POST['confirm_submit_button'] == 'confirm') {
                $crud_string = 'confirm';
            }
            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }
            if (isset($_SESSION['req_from_list_view'])) {
                $crud_string = strtolower($_SESSION['req_from_list_view']);
                unset($_SESSION['req_from_list_view']);
            }  

            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                          $sqlsrr = "SELECT $indent_master_tab.Status FROM  `$indent_master_tab` WHERE `$indent_master_tab`.`ID` = '$data'";                    
                          $indent_data = $dbutil->getSqlData($sqlsrr); 
                         
                        if(!empty($indent_data) && $indent_data[0]['Status']==0){
                             
                               $sqldetdelete="Delete $indent_detail_tab,$indent_master_tab from $indent_master_tab
                                        LEFT JOIN  $indent_detail_tab ON $indent_master_tab.ID=$indent_detail_tab.purchaseindent_ID 
                                        where $indent_detail_tab.purchaseindent_ID=$data";  
                     
                                $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Purchase Indent deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/manage');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        } 
                        }else{
                        $this->tpl->set('message', 'This Purchase Indent form cannot be deleted because it is already in approved state.');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        }
                    
                      
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT $indent_master_tab.*,$indent_detail_tab.*,$rawmaterial_table.Grade FROM  `$indent_master_tab` LEFT JOIN `$indent_detail_tab` ON  `$indent_master_tab`.`ID`=`$indent_detail_tab`.`purchaseindent_ID` LEFT JOIN `$rawmaterial_table` ON  `$indent_detail_tab`.`rawmaterial_ID`=`$rawmaterial_table`.`ID`  WHERE `$indent_master_tab`.`ID` = '$data' ORDER BY $indent_detail_tab.ID ASC";                    
                    $indent_data = $dbutil->getSqlData($sqlsrr); 
                  
                    //edit option     
                    $this->tpl->set('message', 'You can view Purchase Indent form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $indent_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/purchase_indent_form.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
                    $mode='edit';
                    if(isset($_SESSION['ycs_ID']))
                    {
                        $data = trim($_SESSION['ycs_ID']);
                        unset($_SESSION['ycs_ID']);
                        $mode='Confirm';
                    }
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', $mode);
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT $indent_master_tab.*,$indent_detail_tab.*,$rawmaterial_table.Grade FROM  `$indent_master_tab` LEFT JOIN `$indent_detail_tab` ON  `$indent_master_tab`.`ID`=`$indent_detail_tab`.`purchaseindent_ID` LEFT JOIN `$rawmaterial_table` ON  `$indent_detail_tab`.`rawmaterial_ID`=`$rawmaterial_table`.`ID`  WHERE `$indent_master_tab`.`ID` = '$data' ORDER BY $indent_detail_tab.ID ASC";                    
                    $indent_data = $dbutil->getSqlData($sqlsrr); 
                
                    //edit option     
                    $this->tpl->set('message', 'You can edit Purchase Indent form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $indent_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/purchase_indent_form.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);

                    
                    $sqldet_del = "DELETE FROM $indent_detail_tab WHERE purchaseindent_ID=$data";
                    $stmt = $this->db->prepare($sqldet_del);
                    $stmt->execute();   
                            
                            try{
                            
                            $indent_no= $form_post_data['PurchaseIndentNo'];
                            
                            $sql_update="Update $indent_master_tab SET PurchaseIndentNo='$indent_no' WHERE ID=$data";
                            $stmt1 = $this->db->prepare($sql_update);
                            
                        if($stmt1->execute()){
                        
                        FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                                
                                $rawmaterialname =$form_post_data['rawmaterial_' . $entry_count];
                                $quantity =$form_post_data['Quantity_' . $entry_count];
                                $unit_id =$form_post_data['unit_' . $entry_count];
                                $req_for_pono =$form_post_data['Water_' . $entry_count];
                                $req_on=!empty($form_post_data['Emp_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['Emp_'. $entry_count])):'';
                                $remarks =$form_post_data['Note_' . $entry_count];
                                
                               
                            if(!empty($rawmaterialname) && !empty($quantity) && !empty($unit_id) ){
                               
                                $vals = "'" . $data . "'," .
                                        "'" . $rawmaterialname . "'," .
                                        "'" . $quantity . "'," .
                                        "'" . $unit_id . "'," .
                                        "'" . $req_for_pono . "'," .
                                        "'" . $req_on . "'," .
                                        "'" . $remarks . "'" ;
  
                                $sql2 = "INSERT INTO $indent_detail_tab
                                        ( 
                                            `purchaseindent_ID`, 
                                            `rawmaterial_ID`,
                                            `Quantity`,
                                            `unit_ID`,
                                            `PONo`,
                                            `RequiredOn`,
                                            `Remarks`
                                        ) 
                                VALUES ($vals)";

                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            }
                            }
                        }
                            $this->tpl->set('message', 'Purchase Indent form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/manage');
                           
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/purchase_indent_form.php'));
                            }

                    break;
                 case 'confirm':
                    if (isset($crud_string)) {
                            $form_post_data = $dbutil->arrFltr($_POST);
                                               
                            
                            $data=$form_post_data['ycs_ID'];
                            $approved_by= $form_post_data['ApprovedBy'];
                           
                            $sql_update="Update $approvalprocess_tab set ApprovalStatus=1 WHERE process_ID=$data and ProcessType='Purchase Indent'";
                            $stmt1 = $this->db->prepare($sql_update);
                            $stmt1->execute();
                            
                            $sql_update="Update $indent_master_tab set Status=1,ApprovedBy='$approved_by' WHERE ID=$data";
                            $stmt = $this->db->prepare($sql_update);
                            $stmt->execute();
                            
                            
                            $this->tpl->set('message', 'Purchase Indent form Confirmed successfully!');   
                            // $this->tpl->set('label', 'List');
                            header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/manage');
                            $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                            
                    }
                break;
                case 'addsubmit':
                     if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                    
					
                                $val =  "'" . $form_post_data['PurchaseIndentNo'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";

                              $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "purchaseindent`
                                            ( 
                                            `PurchaseIndentNo`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                    VALUES ( $val )";
                                    $stmt = $this->db->prepare($sql);
                                    if ($stmt->execute()) { 
                        $lastInsertedID = $this->db->lastInsertId();
                        $dbutil->ApprovalProcess('Purchase Indent',$approve[0][0],$lastInsertedID);
                        FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                               
                                $rawmaterialname =$form_post_data['rawmaterial_' . $entry_count];
                                $quantity =$form_post_data['Quantity_' . $entry_count];
                                $unit_id =$form_post_data['unit_' . $entry_count];
                                $req_for_pono =$form_post_data['Water_' . $entry_count];
                                $req_on=!empty($form_post_data['Emp_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['Emp_'. $entry_count])):'';
                                $remarks =$form_post_data['Note_' . $entry_count];
                                
                            if(!empty($rawmaterialname) && !empty($quantity) && !empty($unit_id) ){
                                $vals = "'" . $lastInsertedID . "'," .
                                        "'" . $rawmaterialname . "'," .
                                        "'" . $quantity . "'," .
                                        "'" . $unit_id . "'," .
                                        "'" . $req_for_pono . "'," .
                                        "'" . $req_on . "'," .
                                        "'" . $remarks . "'" ;
  
                                 
                                $sql2 = "INSERT INTO $indent_detail_tab
                                        ( 
                                            `purchaseindent_ID`, 
                                            `rawmaterial_ID`,
                                            `Quantity`,
                                            `unit_ID`,
                                            `PONo`,
                                            `RequiredOn`,
                                            `Remarks`
                                        ) 
                                VALUES ($vals)";

                                 // this need to be changed in to transaction type
                                
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            }
                               
                            }
                        }
                        
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/manage');
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/purchase_indent_form.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
	                $PurchaseIndentNo=$dbutil->keyGeneration('purchaseindent','PUI','','PurchaseIndentNo');
                    $this->tpl->set('PurchaseIndentNo', $PurchaseIndentNo);
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/purchase_indent_form.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$indent_master_tab.ID",
                "$indent_master_tab.PurchaseIndentNo"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $indent_master_tab.ID DESC";
           }
           
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $indent_master_tab  "
                    . " WHERE "
                    . " $indent_master_tab.entity_ID = $entityID"
                    . " $whereString";
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Purchase Indent No'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_form_purchase_indent.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
////////////////////////////////////////////////////////////////////////////////
//////////////////////////////on access condition failed then //////////////////
//////////////////////////////////////////////////////////////////////////////// 
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    }
    
///////////////////////////////////////////////////

////////////////////// Purchase_Order_Form ////////
    
 function purchaseorder(){
     
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            /////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///////////
            /////////////////////////////////////////////////////////////////
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
            
            include_once 'util/genUtil.php';
            $util = new GenUtil();
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
            $unit_table = $this->crg->get('table_prefix') . 'unit';
            $po_detail_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
            $po_master_tab = $this->crg->get('table_prefix') . 'purchaseorder';
            $supplier_tab = $this->crg->get('table_prefix') . 'supplier';
            $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
            $indent_det_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
			$state_tab = $this->crg->get('table_prefix') . 'state';
            
            //indent table data
           
            $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1 and $indent_master_tab.PI_Status=1 ORDER BY $indent_master_tab.ID DESC";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $indent_data  = $stmt->fetchAll();	
            $this->tpl->set('indent_data', $indent_data);
            
            //supplier table data
           
            $sql = "SELECT ID,SupplierName FROM $supplier_tab ORDER BY $supplier_tab.SupplierName ASC";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $supplier_data  = $stmt->fetchAll();	
            $this->tpl->set('supplier_data', $supplier_data);
            
            //rawmaterial table data
           
            $sql = "SELECT ID,RMName FROM $rawmaterial_table";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $rawmaterial_data  = $stmt->fetchAll();	
            $this->tpl->set('rawmaterial_data', $rawmaterial_data);
            
            //unit table data
           
            $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
     
            $this->tpl->set('page_title', 'Purchase Order');	          
            $this->tpl->set('page_header', 'Production');
            
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

            $crud_string = null;
	
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }
            
            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }
            

            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                   
                    $sqlsrr = "SELECT * FROM $po_master_tab WHERE ID=$data";
                    $po_data = $dbutil->getSqlData($sqlsrr); 
                    
                    $sqlsrr = "SELECT * FROM  $po_detail_tab WHERE purchaseorder_ID=$data";
                    $podet_data = $dbutil->getSqlData($sqlsrr); 
                    
                    $purchase_indentno=(count($po_data)>0)?$po_data[0]['purchaseindent_ID']:'';
                     
                    $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                    $indentdet_data = $dbutil->getSqlData($sqlsrr);
                    
                     
                     if(!empty($purchase_indentno)){
                         $sql_update="Update $indent_master_tab SET $indent_master_tab.PI_Status=1 WHERE  $indent_master_tab.ID=$purchase_indentno";
                                     $masterstmt1 = $this->db->prepare($sql_update);
                                     $masterstmt1->execute();
                                     
                        foreach($podet_data as $k=>$v){
                            
                            foreach($indentdet_data as $kk=>$value){
                                
                                if(($value['rawmaterial_ID']==$v['rawmaterial_ID'])){
                                    
                                    $sql_updates="Update $indent_det_tab SET $indent_det_tab.ItemStatus=1,$indent_det_tab.RaisedPOQty=(RaisedPOQty-$v[POQuantity]) WHERE $indent_det_tab.ID=$value[ID]";
                                    $detstmt1 = $this->db->prepare($sql_updates);
                                  $detstmt1->execute();
                                 
                                }
                                
                            }
                            
                        }
                                     
                          
                     }
                     
					$sqldetdelete="DELETE $po_detail_tab,$po_master_tab FROM $po_master_tab
								   LEFT JOIN  $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID 
								   WHERE $po_master_tab.ID=$data";  
					$stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'Purchase Order deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/purchaseorder');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        } 
                        
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                     $sqlsrr = "SELECT  $po_master_tab.*,
                                	   $po_detail_tab.*,
                                       $rawmaterial_table.RMName,
                                       $supplier_tab.SupplierName,
                                       $supplier_tab.AddressLine1,
                                       $supplier_tab.AddressLine2,
                                       $supplier_tab.City,
                                       $state_tab.StateName,
                                       $unit_table.UnitName
                               FROM  $po_master_tab
                               LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                               LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                               LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                               LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                               LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                               WHERE $po_master_tab.ID = '$data' 
                               ORDER BY $po_detail_tab.ID ASC";
                    $indent_data = $dbutil->getSqlData($sqlsrr); 
                    
                            
                    $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1";
                    $stmt = $this->db->prepare($sql);            
                    $stmt->execute();
                    $indentsel_data  = $stmt->fetchAll();	
                    $this->tpl->set('indent_data', $indentsel_data);
                  
                    //edit option     
                    $this->tpl->set('message', 'You can view Purchase Order form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $indent_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/po_order_form.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
                    $mode='edit';
                    if(isset($_SESSION['ycs_ID']))
                    {
                        $data = trim($_SESSION['ycs_ID']);
                        unset($_SESSION['ycs_ID']);
                        $mode='Confirm';
                    }
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', $mode);
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    $sqlsrr = "SELECT  $po_master_tab.*,
                                	   $po_detail_tab.*,
                                       $rawmaterial_table.RMName,
                                       $supplier_tab.SupplierName,
                                       $supplier_tab.AddressLine1,
                                       $supplier_tab.AddressLine2,
                                       $supplier_tab.City,
                                       $state_tab.StateName,
                                       $unit_table.UnitName
                               FROM  $po_master_tab
                               LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                               LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                               LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                               LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                               LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                               WHERE $po_master_tab.ID = '$data' 
                               ORDER BY $po_detail_tab.ID ASC";
                    $indent_data = $dbutil->getSqlData($sqlsrr); 
                    
                     $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1";
                    $stmt = $this->db->prepare($sql);            
                    $stmt->execute();
                    $indentsel_data  = $stmt->fetchAll();	
                    $this->tpl->set('indent_data', $indentsel_data);
                
                    //edit option     
                    $this->tpl->set('message', 'You can edit Purchase Order form');
                    $this->tpl->set('page_header', 'Production');
                    $this->tpl->set('FmData', $indent_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/po_order_form.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);

                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);

                    
                    $sqldet_del = "DELETE FROM $po_detail_tab WHERE purchaseorder_ID=$data";
                    $stmt = $this->db->prepare($sqldet_del);
                    $stmt->execute();   
                            
                            try{
                            
                            $indent_no= $form_post_data['purchaseindent_ID'];
							$supplier_ID= $form_post_data['supplier_ID'];
							$discnt_percent= $form_post_data['DiscountPercent'];
							$discnt_amt= $form_post_data['DiscountAmount'];
							$gsttax= $form_post_data['GSTTax'];
							$igsttax= $form_post_data['IGSTTax'];
							$cgsttax= $form_post_data['CGSTTax'];
							$sgsttax= $form_post_data['SGSTTax'];
							$igstamt= $form_post_data['IGSTAmount'];
							$csgstamt= $form_post_data['CGSTAmount'];
							$sgstamt= $form_post_data['SGSTAmount'];
							$billamt= $form_post_data['BillAmount'];
							$netamt= $form_post_data['NetAmount'];
							$paymentterms= $form_post_data['PaymentTerms'];
							$dispatch_date=!empty($form_post_data['DispatchDate'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
						    $delivery_date=!empty($form_post_data['DeliveryDate'])?date("Y-m-d", strtotime($form_post_data['DeliveryDate'])):'';
                            $earlywarningpolicy= $form_post_data['EarlyWarningPolicy'];
							$freightcharges= $form_post_data['FreightCharges'];
							$name_of_transport= $form_post_data['NameOfTransport'];
							$test_certificate= $form_post_data['TestCertificate'];
							$failure_or_damage= $form_post_data['Failure_or_Damage'];
							$special_note= $form_post_data['SpecialNote'];                
                                            
                             
                            
                            $sql_update="Update $po_master_tab SET  purchaseindent_ID='$indent_no',
                                                                    supplier_ID='$supplier_ID',
										                            DiscountPercent='$discnt_percent',
										                            DiscountAmount='$discnt_amt',
										                            GSTTax='$gsttax',
										                            IGSTTax='$igsttax',
										                            CGSTTax='$cgsttax',
										                            SGSTTax='$sgsttax',
										                            IGSTAmount='$isgstamt',
                            										CGSTAmount='$csgstamt',
                            										SGSTAmount='$sgstamt',
                            										BillAmount='$billamt',
                            										NetAmount='$netamt',
                            										PaymentTerms='$paymentterms',
                            										DispatchDate='$dispatch_date',
                            										DeliveryDate='$delivery_date',
                            										EarlyWarningPolicy='$earlywarningpolicy',
                            										FreightCharges='$freightcharges',
                            										NameOfTransport='$name_of_transport',
                            										TestCertificate='$test_certificate',
                            										Failure_or_Damage='$failure_or_damage',
                            										SpecialNote='$special_note'
                                							 WHERE  ID=$data";
                            $stmt1 = $this->db->prepare($sql_update);
                            
                        if($stmt1->execute()){
                        
                        FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                                
                                $itemid =$form_post_data['ItemNo_' . $entry_count]; 
								$packdet =$form_post_data['Packdet_' . $entry_count]; 
								$approved_qty =$form_post_data['Note_' . $entry_count];
								$raisedpo_qty =$form_post_data['RaisedPOQty_' . $entry_count];								
                                $po_qty =$form_post_data['Qty_' . $entry_count];
                                $unit_id =$form_post_data['unit_' . $entry_count];
								$price =$form_post_data['Emp_' . $entry_count];
                                $amount =$form_post_data['Amount_' . $entry_count];
                                
                               
                            if(!empty($itemid) && !empty($po_qty) && !empty($price) ){
                               
                                $vals = "'" . $data . "'," .
                                        "'" . $itemid . "'," .
                                        "'" . $packdet . "'," .
                                        "'" . $approved_qty . "'," .
                                        "'" . $raisedpo_qty . "'," .
                                        "'" . $po_qty . "'," .
                                        "'" . $unit_id . "'," .
										"'" . $price . "'," .
                                        "'" . $amount . "'" ;
  
                                $sql2 = "INSERT INTO $po_detail_tab
                                        ( 
                                            `purchaseorder_ID`, 
                                            `rawmaterial_ID`,
                                            `PackDetails`,
											`ApprovedQty`,
											`RaisedPOQty`,
											`POQuantity`,
											`unit_ID`,
                                            `Rate`,
                                            `Amount`
                                        ) 
                                VALUES ($vals)";

                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                            }
                            }
                        }
                            $this->tpl->set('message', 'Purchase Order form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/purchaseorder');
                           
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/po_order_form.php'));
                            }

                    break;
					
                case 'addsubmit':
                    
					if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
						$dispatch_date=!empty($form_post_data['DispatchDate'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
						$delivery_date=!empty($form_post_data['DeliveryDate'])?date("Y-m-d", strtotime($form_post_data['DeliveryDate'])):'';
					    $purchase_indentno=$form_post_data['purchaseindent_ID'];
					    
                                $val =  "'" . $form_post_data['PurchaseOrderNo'] . "'," .
										"'" . $purchase_indentno . "'," .
										"'" . $form_post_data['supplier_ID'] . "'," .
										"'" . $form_post_data['DiscountPercent'] . "'," .
										"'" . $form_post_data['DiscountAmount'] . "'," .
										"'" . $form_post_data['GSTTax'] . "'," .
										"'" . $form_post_data['IGSTTax'] . "'," .
										"'" . $form_post_data['CGSTTax'] . "'," .
										"'" . $form_post_data['SGSTTax'] . "'," .
										"'" . $form_post_data['IGSTAmount'] . "'," .
										"'" . $form_post_data['CGSTAmount'] . "'," .
										"'" . $form_post_data['SGSTAmount'] . "'," .
										"'" . $form_post_data['BillAmount'] . "'," .
										"'" . $form_post_data['NetAmount'] . "'," .
										"'" . $form_post_data['PaymentTerms'] . "'," .
										"'" . $dispatch_date . "'," .
										"'" . $delivery_date . "'," .
										"'" . $form_post_data['EarlyWarningPolicy'] . "'," .
										"'" . $form_post_data['FreightCharges'] . "'," .
										"'" . $form_post_data['NameOfTransport'] . "'," .
										"'" . $form_post_data['TestCertificate'] . "'," .
										"'" . $form_post_data['Failure_or_Damage'] . "'," .
										"'" . $form_post_data['SpecialNote'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";

                              $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "purchaseorder`
                                            ( 
                                            `PurchaseOrderNo`,
											`purchaseindent_ID`,
											`supplier_ID`,
											`DiscountPercent`,
											`DiscountAmount`,
                                            `GSTTax`,
                                            `IGSTTax`,
                                            `CGSTTax`,
                                            `SGSTTax`,
                                            `IGSTAmount`,
                                            `CGSTAmount`,
											`SGSTAmount`,
                                            `BillAmount`,
                                            `NetAmount`,
											`PaymentTerms`,
											`DispatchDate`,
											`DeliveryDate`,
											`EarlyWarningPolicy`,
											`FreightCharges`,
											`NameOfTransport`,
											`TestCertificate`,
											`Failure_or_Damage`,
											`SpecialNote`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                    VALUES ( $val )";
                                    $stmt = $this->db->prepare($sql);
                        
						if ($stmt->execute()) { 
						
						$lastInsertedID = $this->db->lastInsertId();
                        
                        FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                               
                                $itemid =$form_post_data['ItemNo_' . $entry_count]; 
								$packdet =$form_post_data['Packdet_' . $entry_count]; 
								$approved_qty =$form_post_data['Note_' . $entry_count];
								$raisedpo_qty =$form_post_data['RaisedPOQty_' . $entry_count];								
                                $po_qty =$form_post_data['Qty_' . $entry_count];
                                $unit_id =$form_post_data['unit_' . $entry_count];
								$price =$form_post_data['Emp_' . $entry_count];
                                $amount =$form_post_data['Amount_' . $entry_count];
                                
                            if(!empty($itemid) && !empty($po_qty) && !empty($price) ){
                                
                                $sql_update="Update $indent_det_tab SET RaisedPOQty=(RaisedPOQty+'$po_qty') WHERE $indent_det_tab.purchaseindent_ID=$purchase_indentno AND $indent_det_tab.rawmaterial_ID=$itemid AND $indent_det_tab.ItemStatus=1";   
					            $update_stmt = $this->db->prepare($sql_update);
					            $update_stmt->execute();
                                
								$vals = "'" . $lastInsertedID . "'," .
                                        "'" . $itemid . "'," .
                                        "'" . $packdet . "'," .
                                        "'" . $approved_qty . "'," .
                                        "'" . $raisedpo_qty . "'," .
                                        "'" . $po_qty . "'," .
                                        "'" . $unit_id . "'," .
										"'" . $price . "'," .
                                        "'" . $amount . "'" ;
  
                                 
                                $sql2 = "INSERT INTO $po_detail_tab
                                        ( 
                                            `purchaseorder_ID`, 
                                            `rawmaterial_ID`,
                                            `PackDetails`,
											`ApprovedQty`,
											`RaisedPOQty`,
											`POQuantity`,
											`unit_ID`,
                                            `Rate`,
                                            `Amount`
                                        ) 
                                VALUES ($vals)";
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();
                               
                            }
                               
                            }
                        }
                        $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                        $indentdet_data = $dbutil->getSqlData($sqlsrr);
                        $checkunique=[];
                        
                             if(!empty($indentdet_data)){
                                 
                                 foreach($indentdet_data as $k=>$v){
                                     
                                     if($v['RaisedPOQty']==$v['Quantity']){
                                         $checkunique[]=1;
                                         $sql_update="Update $indent_det_tab SET ItemStatus='2' WHERE  $indent_det_tab.purchaseindent_ID=$purchase_indentno AND $indent_det_tab.rawmaterial_ID=$v[rawmaterial_ID]";
                                         $stmt1 = $this->db->prepare($sql_update);
                                         $stmt1->execute();
                                         
                                     }else{
                                         $checkunique[]=2; 
                                     }
                                
                                     
                                 }
                                
                                 if(count($checkunique)>0){
                                    if(count(array_unique($checkunique))==1 && end($checkunique) == 1){
                                     $sql_update="Update $indent_master_tab SET PI_Status='2' WHERE  $indent_master_tab.ID=$purchase_indentno";
                                     $stmt1 = $this->db->prepare($sql_update);
                                     $stmt1->execute();
                                    } 
                                 }
                             }
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/purchase/pur/purchaseorder');
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/po_order_form.php'));
                     }
                    break;
                case 'add':
                    $this->tpl->set('mode', 'add');
	                $this->tpl->set('page_header', 'Production');
	                $PurchaseOrderNo=$dbutil->keyGeneration('purchaseorder','PUO','','PurchaseOrderNo');
                    $this->tpl->set('PurchaseOrderNo', $PurchaseOrderNo);
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/po_order_form.php'));
                    break;

                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$po_master_tab.ID",
                "$po_master_tab.PurchaseOrderNo"
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }

            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {

	            if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
        		    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }

                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $po_master_tab.ID DESC";
           }
           
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $po_master_tab  "
                    . " WHERE "
                    . " $po_master_tab.entity_ID = $entityID"
                    . " $whereString";
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Purchase Order No'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
                        
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/crud_form_purchase_order.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }

	    ///////////////Use different template////////////////////
	    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
		///////////////////////////////////////////////////////////////////
		//////////////////////////////on access condition failed then /////
		///////////////////////////////////////////////////////////////////
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    } 
}
