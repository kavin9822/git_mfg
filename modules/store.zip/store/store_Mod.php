<?php

/**
 * Description of Purchase_Mod
 *
 * @author psmahadevan
 */
class store_Mod {

    private $crg;
    private $ses;
    private $db;
    private $sd;
    private $tpl;
    private $rbac;

    public function __construct($reg = NULL) {
        /*
         * Receiving $rg array
         */
        $this->crg = $reg;

        /*
         * geting object from reg array
         */
        $this->ses = $this->crg->get('ses');
        $this->db = $this->crg->get('db');
        $this->sd = $this->crg->get('SD');
        $this->tpl = $this->crg->get('tpl');
        $this->rbac = $this->crg->get('rbac');
    }



///////////////////////////////////////
//////////////////////////////////////
//////////////////////////////// material_inward



function materialinward(){
     
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
         
        /////////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied///////////
        /////////////////////////////////////////////////////////////////
        
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
        
        include_once 'util/genUtil.php';
        $util = new GenUtil();
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
        $unit_table = $this->crg->get('table_prefix') . 'unit';
        $po_detail_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
        $po_master_tab = $this->crg->get('table_prefix') . 'purchaseorder';
        $supplier_tab = $this->crg->get('table_prefix') . 'supplier';
        $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
        $indent_det_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
        $state_tab = $this->crg->get('table_prefix') . 'state';
        $unit_tab = $this->crg->get('table_prefix') . 'unit';
        $material_inward_tab = $this->crg->get('table_prefix') . 'material_inward';
        $material_inward_detail_tab = $this->crg->get('table_prefix') . 'material_inward_detail';
        
        //indent table data
       
        $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1 and $indent_master_tab.PI_Status=1 ORDER BY $indent_master_tab.ID DESC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $indent_data  = $stmt->fetchAll();	
        $this->tpl->set('indent_data', $indent_data);


         //perchase Order table data
       
         $sql = "SELECT ID,PurchaseOrderNo,purchaseindent_ID FROM $po_master_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $po_master_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('po_master_tab', $po_master_tab_data);
        
        //supplier table data
       
        $sql = "SELECT ID,SupplierName FROM $supplier_tab ORDER BY $supplier_tab.SupplierName ASC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $supplier_data  = $stmt->fetchAll();	
        $this->tpl->set('supplier_data', $supplier_data);
        
        //rawmaterial table data
       
        $sql = "SELECT ID,RMName FROM $rawmaterial_table";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $rawmaterial_data  = $stmt->fetchAll();	
        $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
        //unit table data
       
        $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
        $stmt = $this->db->prepare($pdt_sql);            
        $stmt->execute();
        $unit_data  = $stmt->fetchAll();	
        $this->tpl->set('unit_data', $unit_data);
 
        $this->tpl->set('page_title', 'Material Inward');	          
        $this->tpl->set('page_header', 'Store');
        
        //Add Role when u submit the add role form
        $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

        $crud_string = null;

        if (isset($_POST['req_from_list_view'])) {
            $crud_string = strtolower($_POST['req_from_list_view']);
        }              
        
        //Edit submit
        if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
            $crud_string = 'editsubmit';
        }
        
        //Add submit
        if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
            $crud_string = 'addsubmit';
        }
        

        switch ($crud_string) {
             case 'delete':                    
                  $data = trim($_POST['ycs_ID']);
                   
                   
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                   
                }
               
                // $sqlsrr = "SELECT * FROM $po_master_tab WHERE ID=$data";
                // $po_data = $dbutil->getSqlData($sqlsrr); 
                
                // $sqlsrr = "SELECT * FROM  $po_detail_tab WHERE purchaseorder_ID=$data";
                // $podet_data = $dbutil->getSqlData($sqlsrr); 
                
                // $purchase_indentno=(count($po_data)>0)?$po_data[0]['purchaseindent_ID']:'';
                 
                // $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                // $indentdet_data = $dbutil->getSqlData($sqlsrr);
                
                 
                //  if(!empty($purchase_indentno)){
                //      $sql_update="Update $indent_master_tab SET $indent_master_tab.PI_Status=1 WHERE  $indent_master_tab.ID=$purchase_indentno";
                //                  $masterstmt1 = $this->db->prepare($sql_update);
                //                  $masterstmt1->execute();
                                 
                //     foreach($podet_data as $k=>$v){
                        
                //         foreach($indentdet_data as $kk=>$value){
                            
                //             if(($value['rawmaterial_ID']==$v['rawmaterial_ID'])){
                                
                //                 $sql_updates="Update $indent_det_tab SET $indent_det_tab.ItemStatus=1,$indent_det_tab.RaisedPOQty=(RaisedPOQty-$v[POQuantity]) WHERE $indent_det_tab.ID=$value[ID]";
                //                 $detstmt1 = $this->db->prepare($sql_updates);
                //               $detstmt1->execute();
                             
                //             }
                            
                //         }
                        
                //     }
                                 
                      
                //  }
                 
                $sqldetdelete="DELETE $material_inward_detail_tab,$material_inward_tab FROM $material_inward_tab
                               LEFT JOIN  $material_inward_detail_tab ON $material_inward_tab.ID=$material_inward_detail_tab.material_inward_id 
                               WHERE $material_inward_tab.ID=$data";  
                $stmt = $this->db->prepare($sqldetdelete);            
                    
                    if($stmt->execute()){
                    $this->tpl->set('message', 'Material Inward deleted successfully');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/materialinward');
                    // $this->tpl->set('label', 'List');
                    // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    } 
                    
        break;
            case 'view':                    
                $data = trim($_POST['ycs_ID']);
             
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to view!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', 'view');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                //  $sqlsrr = "SELECT  $po_master_tab.*,
                //                    $po_detail_tab.*,
                //                    $rawmaterial_table.RMName,
                //                    $supplier_tab.SupplierName,
                //                    $supplier_tab.AddressLine1,
                //                    $supplier_tab.AddressLine2,
                //                    $supplier_tab.City,
                //                    $state_tab.StateName,
                //                    $unit_table.UnitName
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";
                // $indent_data = $dbutil->getSqlData($sqlsrr); 
                $sqlsrr="SELECT * FROM $material_inward_tab,$material_inward_detail_tab
                WHERE  $material_inward_tab.ID = $material_inward_detail_tab.material_inward_id
                AND $material_inward_tab.ID = $data";   
                
                $indent_data = $dbutil->getSqlData($sqlsrr);               
              
                
                        
               
                
                
                //edit option     
                $this->tpl->set('message', 'You can view Material Inward form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/material_inward.php'));                    
                break;
            
            case 'edit':                    
                $data = trim($_POST['ycs_ID']);
                $mode='edit';
                if(isset($_SESSION['ycs_ID']))
                {
                    $data = trim($_SESSION['ycs_ID']);
                    unset($_SESSION['ycs_ID']);
                    $mode='Confirm';
                }
           // var_dump($data);
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to edit!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', $mode);
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                // $sqlsrr = "SELECT  *,$enquiry_tab.PONo,
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";


               $sqlsrr="SELECT * FROM $material_inward_tab,$material_inward_detail_tab
                WHERE  $material_inward_tab.ID = $material_inward_detail_tab.material_inward_id
                AND $material_inward_tab.ID = $data";         

                $indent_data = $dbutil->getSqlData($sqlsrr);               
                $indentsel_data  = $stmt->fetchAll();	
                $this->tpl->set('indent_data', $indentsel_data);
            
                //edit option     
                $this->tpl->set('message', 'You can edit Material Inward form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/material_inward.php'));                    
                break;
            
            case 'editsubmit':             
                $data = trim($_POST['ycs_ID']);
              

                //mode of form submit
                $this->tpl->set('mode', 'edit');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);

                //Post data
                include_once 'util/genUtil.php';
                $util = new GenUtil();
                $form_post_data = $util->arrFltr($_POST);

                //      echo '<pre>';
                //    print_r($form_post_data); die;
                    
                // $sqldet_del = "DELETE FROM $po_detail_tab WHERE purchaseorder_ID=$data";
                // $stmt = $this->db->prepare($sqldet_del);
                // $stmt->execute();   
                        
                        try{
                            
                                                    
                    
        
                        
                        $MaterialNo= $form_post_data['MaterialNo'];
                        $PurchaseNO= $form_post_data['PurchaseNO'];
                        $Store= $form_post_data['Store'];
                        // $Purchase_Indent_No= $form_post_data['Purchase_Indent_No'];
                        $Supplier_Name= $form_post_data['Supplier_Name'];      
                        
                        $sql_update="Update $material_inward_tab SET  MaterialNo='$MaterialNo',

                                                 PurchaseNO='$PurchaseNO',
                                                 Store='$Store',    
                                                  Supplier_Name='$Supplier_Name'                                                               
                                                  WHERE  ID=$data"; 

                        $stmt1 = $this->db->prepare($sql_update);
                        $stmt1->execute();

                        
						 $sql3 = "DELETE FROM $material_inward_detail_tab WHERE material_inward_id=$data";
					     $stmt3 = $this->db->prepare($sql3);

                    if($stmt3->execute()){
                        
            //    echo         $form_post_data['maxCount'];    die;

                    FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                            
                            
                            // $itemid =$form_post_data['ItemNo_' . $entry_count]; 
                            // $packdet =$form_post_data['Packdet_' . $entry_count]; 
                            // $approved_qty =$form_post_data['Note_' . $entry_count];
                            // $raisedpo_qty =$form_post_data['RaisedPOQty_' . $entry_count];								
                            // $po_qty =$form_post_data['Qty_' . $entry_count];
                            // $unit_id =$form_post_data['unit_' . $entry_count];
                            // $price =$form_post_data['Emp_' . $entry_count];
                            // $amount =$form_post_data['Amount_' . $entry_count];
                            
                            $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                            $itemid =$form_post_data['Iterm_description_' . $entry_count]; 
                            $poqty =$form_post_data['po_qty_' . $entry_count]; 
                            $pendingqt =$form_post_data['pending_qty_' . $entry_count];
                            $rqt =$form_post_data['recevied_qt_' . $entry_count];								
                            $unit =$form_post_data['unit_' . $entry_count];
                            $receivedqt =$form_post_data['received_qt_in_kg_' . $entry_count];
                            $batch =$form_post_data['batch_no_' . $entry_count];
                            $costunit =$form_post_data['cost_unit_' . $entry_count];
                            $total =$form_post_data['total_' . $entry_count];
                            $supplier =$form_post_data['supplier_invoice_no_' . $entry_count];
                           
                            if(!empty($total)){
                           
                            // $vals = "'" . $data . "'," .
                            //         "'" . $itemid . "'," .
                            //         "'" . $packdet . "'," .
                            //         "'" . $approved_qty . "'," .
                            //         "'" . $raisedpo_qty . "'," .
                            //         "'" . $po_qty . "'," .
                            //         "'" . $unit_id . "'," .
                            //         "'" . $price . "'," .
                            //         "'" . $amount . "'" ;
                            
                            // -- `purchaseorder_ID`, 
                            // -- `rawmaterial_ID`,
                            // -- `PackDetails`,
                            // -- `ApprovedQty`,
                            // -- `RaisedPOQty`,
                            // -- `POQuantity`,
                            // -- `unit_ID`,
                            // -- `Rate`,
                            // -- `Amount`

                                    $vals = "'" . $data . "'," .
                                    "'" . $itemid . "'," .
                                    "'" . $poqty . "'," .
                                    "'" . $pendingqt . "'," .
                                    "'" . $rqt . "'," .
                                    "'" . $unit . "'," .
                                    "'" . $receivedqt . "'," .
                                    "'" . $batch . "'," .
                                    "'" . $costunit . "'," .
                                    "'" . $total . "'," .
                                    "'" . $supplier . "'," .
                                    "'" . $invoice_date . "'" ;   

                            $sql2 = "INSERT INTO $material_inward_detail_tab
                                    ( 

                                        `material_inward_id`, 
                                        `Iterm_description`,
                                        `po_qty`,
                                        `pending_qty`,
                                        `recevied_qt`,
                                        `unit`,
                                        `received_qt_in_kg`,
                                        `batch_no`,
                                        `cost_unit`,
                                        `total`,
                                        `supplier_invoice_no`,
                                        `invoice_date`
                                    ) 
                            VALUES ($vals)";        

                            $stmt = $this->db->prepare($sql2);
                            $stmt->execute();               
                        }
                        }           

                        
                    }
                                    
                        $this->tpl->set('message', 'Material Inward form edited successfully!');   
                        header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/materialinward');
                       
                        } catch (Exception $exc) {
                         //edit failed option
                        $this->tpl->set('message', 'Failed to edit, try again!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/material_inward.php'));
                        }

                break;
                
            case 'addsubmit':
                
                if (isset($crud_string)) {
                     
                    $form_post_data = $dbutil->arrFltr($_POST);
                    // $dispatch_date=!empty($form_post_data['invoice_date_'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
                    // $delivery_date=!empty($form_post_data['DeliveryDate'])?date("Y-m-d", strtotime($form_post_data['DeliveryDate'])):'';
                    // "'" . $dispatch_date . "'," .
                    // $purchase_indentno=$form_post_data['purchaseindent_ID'];
                //     echo '<pre>';
                //    print_r($form_post_data); die;
                    
                            $val =  "'" . $form_post_data['MaterialNo'] . "'," .                                  
                                    "'" . $form_post_data['PurchaseNO'] . "'," .
                                    "'" . $form_post_data['Store'] . "'," .
                                    // "'" . $form_post_data['Purchase_Indent_No'] . "'," .
                                    "'" . $form_post_data['Supplier_Name'] . "'," .
                                    "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                    "'" .  $this->ses->get('user')['ID'] . "'";

                         $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "material_inward`
                                        ( 
                                        `MaterialNo`,
                                        `PurchaseNO`,
                                        `Store`,
                                       
                                        `Supplier_Name`,
                                        `entity_ID`,
                                        `users_ID`
                                        ) 
                                VALUES ( $val )";
                                $stmt = $this->db->prepare($sql);       
                    if ($stmt->execute()) { 
                    
                    $lastInsertedID = $this->db->lastInsertId();
                      
                
                  FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {

                             $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                            $itemid =$form_post_data['Iterm_description_' . $entry_count]; 
                            $poqty =$form_post_data['po_qty_' . $entry_count]; 
                            $pendingqt =$form_post_data['pending_qty_' . $entry_count];
                            $rqt =$form_post_data['recevied_qt_' . $entry_count];								
                            $unit =$form_post_data['unit_' . $entry_count];
                            $receivedqt =$form_post_data['received_qt_in_kg_' . $entry_count];
                            $batch =$form_post_data['batch_no_' . $entry_count];
                            $costunit =$form_post_data['cost_unit_' . $entry_count];
                            $total =$form_post_data['total_' . $entry_count];
                            $supplier =$form_post_data['supplier_invoice_no_' . $entry_count];
                            // $invoice =$form_post_data['invoice_date_' . $entry_count];
                            
                            
                        
                            
                           
                            
                            $vals = "'" . $lastInsertedID . "'," .
                                    "'" . $itemid . "'," .
                                    "'" . $poqty . "'," .
                                    "'" . $pendingqt . "'," .
                                    "'" . $rqt . "'," .
                                    "'" . $unit . "'," .
                                    "'" . $receivedqt . "'," .
                                    "'" . $batch . "'," .
                                    "'" . $costunit . "'," .
                                    "'" . $total . "'," .
                                    "'" . $supplier . "'," .
                                    "'" . $invoice_date . "'" ;   
                      $sql2 = "INSERT INTO $material_inward_detail_tab
                                    ( 
                                        `material_inward_id`, 
                                        `Iterm_description`,
                                        `po_qty`,
                                        `pending_qty`,
                                        `recevied_qt`,
                                        `unit`,
                                        `received_qt_in_kg`,
                                        `batch_no`,
                                        `cost_unit`,
                                        `total`,
                                        `supplier_invoice_no`,
                                        `invoice_date`
                                    ) 
                            VALUES ($vals)";
                            $stmt = $this->db->prepare($sql2);
                        $stmt->execute();  
                       
                           
                        }
                        
                        
                      
                    }
                                                       
                    $this->tpl->set('mode', 'add');
                    $this->tpl->set('message', '- Success -');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/materialinward');
                 } else {
                        //edit option
                        //if submit failed to insert form
                        $this->tpl->set('message', 'Failed to submit!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/material_inward.php'));
                 }
                 
                break;

            case 'add':
                $this->tpl->set('mode', 'add');
                $this->tpl->set('page_header', 'Store');
                $MaterialNo=$dbutil->keyGeneration('materialinward','MNO','','MaterialNo');
                $this->tpl->set('MaterialNo', $MaterialNo);
                $this->tpl->set('content', $this->tpl->fetch('factory/form/material_inward.php'));
                break;

            default:
                /*
                 * List form
                 */
                 
                ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
     $colArr = array(
            "$material_inward_tab.ID",
            "$material_inward_tab.MaterialNo",
            "$material_inward_tab.PurchaseNO",
           
           
            
            // "$po_master_tab.ID"

        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

            if (strpos($colNames, 'DATE') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
            }else {
                $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
            }

              if ('' != $x) {
               $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
       IF (count($wsarr) >= 1) {
            $whereString = ' AND '. implode(' AND ', $wsarr);
        }
       } else {
         $whereString ="ORDER BY $material_inward_tab.ID DESC";
       }
       
    $sql = "SELECT "
                . implode(',',$colArr)
                . " FROM $material_inward_tab "
                . " WHERE "
                . " $material_inward_tab.entity_ID = $entityID"
                . " $whereString";  
        
     

            $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
        /*
         * SET DATA TO TEMPLATE
                    */
       $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
     
     
        $this->tpl->set('table_columns_label_arr', array('ID','Material NO','Purchase Order No'));
        
        /*
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
        // $this->tpl->set('dcpdf','Generate Pdf');            
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
                 
                include_once $this->tpl->path . '/factory/form/material_inward_crud_form.php';
                $cus_form_data = Form_Elements::data($this->crg);
                include_once 'util/crud3_1.php';
                new Crud3($this->crg, $cus_form_data);
                break;
        }

    ///////////////Use different template////////////////////
    $this->tpl->set('master_layout', 'layout_datepicker.php');
//     $this->tpl->set('master_layout', 'layout_chart.php');  
      // $this->tpl->set('master_layout', 'layout_datepicker.php'); 
    ///////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then /////
    ///////////////////////////////////////////////////////////////////
 } else {
         if ($this->ses->get('user')['ID']) {
             $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
         } else {
             header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
         }
     }
} 

//////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////
    //////////////////////////////Qc Material Inwards /////
    ///////////////////////////////////////////////////////////////////

function qcmaterialinward(){
     
        if ($this->crg->get('wp') || $this->crg->get('rp')) {
             
            /////////////////////////////////////////////////////////////////
            //////////////////////////////access condition applied///////////
            /////////////////////////////////////////////////////////////////
            
            include_once 'util/DBUTIL.php';
            $dbutil = new DBUTIL($this->crg);
            
            include_once 'util/genUtil.php';
            $util = new GenUtil();
             
            $entityID = $this->ses->get('user')['entity_ID'];
            $userID = $this->ses->get('user')['ID'];
            $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
            $unit_table = $this->crg->get('table_prefix') . 'unit';
            $po_detail_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
            $po_master_tab = $this->crg->get('table_prefix') . 'purchaseorder';
            $supplier_tab = $this->crg->get('table_prefix') . 'supplier';
            $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
            $indent_det_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
            $state_tab = $this->crg->get('table_prefix') . 'state';
            $unit_tab = $this->crg->get('table_prefix') . 'unit';
            $material_inward_tab = $this->crg->get('table_prefix') . 'material_inward';
            $material_inward_detail_tab = $this->crg->get('table_prefix') . 'material_inward_detail';
            $qc_mast_tab = $this->crg->get('table_prefix') . 'qc_materialinward';
            $qc_detail_tab = $this->crg->get('table_prefix') . 'qc_materialinward_detail';
            
            //indent table data
           
            $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1 and $indent_master_tab.PI_Status=1 ORDER BY $indent_master_tab.ID DESC";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $indent_data  = $stmt->fetchAll();	
            $this->tpl->set('indent_data', $indent_data);
    
             //perchase Order table data
           
             $sql = "SELECT ID,MaterialNo FROM $material_inward_tab";
             $stmt = $this->db->prepare($sql);            
             $stmt->execute();
             $material_inward_tab_data  = $stmt->fetchAll();	
             $this->tpl->set('material_inward_tab_data', $material_inward_tab_data);
    
             //perchase Order table data
           
             $sql = "SELECT ID,PurchaseOrderNo,purchaseindent_ID FROM $po_master_tab";
             $stmt = $this->db->prepare($sql);            
             $stmt->execute();
             $po_master_tab_data  = $stmt->fetchAll();	
             $this->tpl->set('po_master_tab', $po_master_tab_data);
            
            //supplier table data
           
            $sql = "SELECT ID,SupplierName FROM $supplier_tab ORDER BY $supplier_tab.SupplierName ASC";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $supplier_data  = $stmt->fetchAll();	
            $this->tpl->set('supplier_data', $supplier_data);
            
            //rawmaterial table data
           
            $sql = "SELECT ID,RMName FROM $rawmaterial_table";
            $stmt = $this->db->prepare($sql);            
            $stmt->execute();
            $rawmaterial_data  = $stmt->fetchAll();	
            $this->tpl->set('rawmaterial_data', $rawmaterial_data);
            
            //unit table data
           
            $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
            $stmt = $this->db->prepare($pdt_sql);            
            $stmt->execute();
            $unit_data  = $stmt->fetchAll();	
            $this->tpl->set('unit_data', $unit_data);
     
            $this->tpl->set('page_title', 'Qc Material Inward');	          
            $this->tpl->set('page_header', 'Store');
            
            //Add Role when u submit the add role form
            $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];
    
            $crud_string = null;
    
            if (isset($_POST['req_from_list_view'])) {
                $crud_string = strtolower($_POST['req_from_list_view']);
            }              
            
            //Edit submit
            if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
                $crud_string = 'editsubmit';
            }
            
            //Add submit
            if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
                $crud_string = 'addsubmit';
            }
            
    
            switch ($crud_string) {
                 case 'delete':                    
                      $data = trim($_POST['ycs_ID']);
                       
                       
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                       
                    }
                   
                    // $sqlsrr = "SELECT * FROM $po_master_tab WHERE ID=$data";
                    // $po_data = $dbutil->getSqlData($sqlsrr); 
                    
                    // $sqlsrr = "SELECT * FROM  $po_detail_tab WHERE purchaseorder_ID=$data";
                    // $podet_data = $dbutil->getSqlData($sqlsrr); 
                    
                    // $purchase_indentno=(count($po_data)>0)?$po_data[0]['purchaseindent_ID']:'';
                     
                    // $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                    // $indentdet_data = $dbutil->getSqlData($sqlsrr);
                    
                     
                    //  if(!empty($purchase_indentno)){
                    //      $sql_update="Update $indent_master_tab SET $indent_master_tab.PI_Status=1 WHERE  $indent_master_tab.ID=$purchase_indentno";
                    //                  $masterstmt1 = $this->db->prepare($sql_update);
                    //                  $masterstmt1->execute();
                                     
                    //     foreach($podet_data as $k=>$v){
                            
                    //         foreach($indentdet_data as $kk=>$value){
                                
                    //             if(($value['rawmaterial_ID']==$v['rawmaterial_ID'])){
                                    
                    //                 $sql_updates="Update $indent_det_tab SET $indent_det_tab.ItemStatus=1,$indent_det_tab.RaisedPOQty=(RaisedPOQty-$v[POQuantity]) WHERE $indent_det_tab.ID=$value[ID]";
                    //                 $detstmt1 = $this->db->prepare($sql_updates);
                    //               $detstmt1->execute();
                                 
                    //             }
                                
                    //         }
                            
                    //     }
                                     
                          
                    //  }
                     
                    $sqldetdelete="DELETE $qc_detail_tab,$qc_mast_tab FROM $qc_mast_tab
                                   LEFT JOIN  $qc_detail_tab ON $qc_mast_tab.ID=$qc_detail_tab.qc_material_id 
                                   WHERE $qc_mast_tab.ID=$data";  
                    $stmt = $this->db->prepare($sqldetdelete);            
                        
                        if($stmt->execute()){
                        $this->tpl->set('message', 'QC Material Inward deleted successfully');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/qcmaterialinward');
                        // $this->tpl->set('label', 'List');
                        // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        } 
                        
            break;
                case 'view':                    
                    $data = trim($_POST['ycs_ID']);
                 
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to view!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'view');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    //  $sqlsrr = "SELECT  $po_master_tab.*,
                    //                    $po_detail_tab.*,
                    //                    $rawmaterial_table.RMName,
                    //                    $supplier_tab.SupplierName,
                    //                    $supplier_tab.AddressLine1,
                    //                    $supplier_tab.AddressLine2,
                    //                    $supplier_tab.City,
                    //                    $state_tab.StateName,
                    //                    $unit_table.UnitName
                    //            FROM  $po_master_tab
                    //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                    //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                    //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                    //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                    //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                    //            WHERE $po_master_tab.ID = '$data' 
                    //            ORDER BY $po_detail_tab.ID ASC";
                    // $indent_data = $dbutil->getSqlData($sqlsrr); 
                    $sqlsrr="SELECT * FROM $qc_mast_tab,$qc_detail_tab
                    WHERE  $qc_mast_tab.ID = $qc_detail_tab.qc_material_id
                    AND $qc_mast_tab.ID = $data";   
                    
                    $indent_data = $dbutil->getSqlData($sqlsrr);               
                  
                    
                            
                   
                    
                    
                    //edit option     
                    $this->tpl->set('message', 'You can view Qc Material Inward form');
                    $this->tpl->set('page_header', 'Store');
                    $this->tpl->set('FmData', $indent_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/qc_material_inward.php'));                    
                    break;
                
                case 'edit':                    
                    $data = trim($_POST['ycs_ID']);
                    $mode='edit';
                    if(isset($_SESSION['ycs_ID']))
                    {
                        $data = trim($_SESSION['ycs_ID']);
                        unset($_SESSION['ycs_ID']);
                        $mode='Confirm';
                    }
               // var_dump($data);
                    if (!$data) {
                        $this->tpl->set('message', 'Please select any one ID to edit!');
                        $this->tpl->set('label', 'List');
                        $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                        break;
                    }
                    
                    //mode of form submit
                    $this->tpl->set('mode', $mode);
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);         
                                
                    // $sqlsrr = "SELECT  *,$enquiry_tab.PONo,
                    //            FROM  $po_master_tab
                    //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                    //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                    //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                    //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                    //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                    //            WHERE $po_master_tab.ID = '$data' 
                    //            ORDER BY $po_detail_tab.ID ASC";
    
    
                    $sqlsrr="SELECT * FROM $qc_mast_tab,$qc_detail_tab
                    WHERE  $qc_mast_tab.ID = $qc_detail_tab.qc_material_id
                    AND $qc_mast_tab.ID = $data";    
    
                    $indent_data = $dbutil->getSqlData($sqlsrr);               
                    $indentsel_data  = $stmt->fetchAll();	
                    $this->tpl->set('indent_data', $indentsel_data);
                
                    //edit option     
                    $this->tpl->set('message', 'You can edit Qc Material Inward form');
                    $this->tpl->set('page_header', 'Store');
                    $this->tpl->set('FmData', $indent_data); 
                    
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/qc_material_inward.php'));                    
                    break;
                
                case 'editsubmit':             
                    $data = trim($_POST['ycs_ID']);
                    
                    //mode of form submit
                    $this->tpl->set('mode', 'edit');
                    //set id to edit $ycs_ID
                    $this->tpl->set('ycs_ID', $data);
    
                    //Post data
                    include_once 'util/genUtil.php';
                    $util = new GenUtil();
                    $form_post_data = $util->arrFltr($_POST);
    
                    
                    // $sqldet_del = "DELETE FROM $po_detail_tab WHERE purchaseorder_ID=$data";
                    // $stmt = $this->db->prepare($sqldet_del);
                    // $stmt->execute();   
                            
                            try{
                                
                                                        
                        
            
                            
                            $MaterialNo= $form_post_data['MaterialNo'];
                            $PurchaseNO= $form_post_data['PurchaseNO'];
                            $Store= $form_post_data['Store'];
                            $Purchase_Indent_No= $form_post_data['Purchase_Indent_No'];
                            $Supplier_Name= $form_post_data['Supplier_Name'];      
                            
                            $sql_update="Update $material_inward_tab SET  MaterialNo='$MaterialNo',
                            PurchaseNO='$PurchaseNO',
                            Store='$Store',
                            Purchase_Indent_No='$Purchase_Indent_No',
                            Supplier_Name='$Supplier_Name'
                                                                    
                                                             WHERE  ID=$data";      
                            $stmt1 = $this->db->prepare($sql_update);
                            $stmt1->execute();

                            $sql3 = "DELETE FROM $qc_detail_tab WHERE qc_material_id=$data";
					     $stmt3 = $this->db->prepare($sql3);

                        if($stmt3->execute()){
                        
                        FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                                
                                
                                // $itemid =$form_post_data['ItemNo_' . $entry_count]; 
                                // $packdet =$form_post_data['Packdet_' . $entry_count]; 
                                // $approved_qty =$form_post_data['Note_' . $entry_count];
                                // $raisedpo_qty =$form_post_data['RaisedPOQty_' . $entry_count];								
                                // $po_qty =$form_post_data['Qty_' . $entry_count];
                                // $unit_id =$form_post_data['unit_' . $entry_count];
                                // $price =$form_post_data['Emp_' . $entry_count];
                                // $amount =$form_post_data['Amount_' . $entry_count];
                                
                                // $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                                // $itemid =$form_post_data['Iterm_description_' . $entry_count]; 
                                // $poqty =$form_post_data['po_qty_' . $entry_count]; 
                                // $pendingqt =$form_post_data['pending_qty_' . $entry_count];
                                // $rqt =$form_post_data['recevied_qt_' . $entry_count];								
                                // $unit =$form_post_data['unit_' . $entry_count];
                                // $receivedqt =$form_post_data['received_qt_in_kg_' . $entry_count];
                                // $batch =$form_post_data['batch_no_' . $entry_count];
                                // $costunit =$form_post_data['cost_unit_' . $entry_count];
                                // $total =$form_post_data['total_' . $entry_count];
                                // $supplier =$form_post_data['supplier_invoice_no_' . $entry_count];

                                $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                                $item_description =$form_post_data['item_description_' . $entry_count]; 
                                $received_qty =$form_post_data['received_qty_' . $entry_count]; 
                                $unit =$form_post_data['unit_' . $entry_count];
                                $received_qty_in_kg =$form_post_data['received_qty_in_kg_' . $entry_count];								
                                $batch_no =$form_post_data['batch_no_' . $entry_count];
                                $supplier_invoice_no =$form_post_data['supplier_invoice_no_' . $entry_count];
                                $total_accepted_qty =$form_post_data['total_accepted_qty_' . $entry_count];
                                $accepted_qty =$form_post_data['accepted_qty_' . $entry_count];
                                $total_rejected_qty =$form_post_data['total_rejected_qty_' . $entry_count];
                                $rejected =$form_post_data['rejected_' . $entry_count];
                                $rejection_reason =$form_post_data['rejection_reason_' . $entry_count];
                               
                                if(!empty($item_description)){
                               
                              

                                        $vals = "'" . $data . "'," .
                                        "'" . $item_description . "'," .
                                        "'" . $received_qty . "'," .
                                        "'" . $unit . "'," .
                                        "'" . $received_qty_in_kg . "'," .
                                        "'" . $batch_no . "'," .
                                        "'" . $supplier_invoice_no . "'," .
                                        "'" . $invoice_date . "'," .
                                        "'" . $total_accepted_qty . "'," .
                                        "'" . $accepted_qty . "'," .
                                        "'" . $total_rejected_qty . "'," .
                                        "'" . $rejected . "'," .
                                        "'" . $rejection_reason . "'" ; 
    
                                $sql2 = "INSERT INTO $qc_detail_tab
                                        ( 
    
                                           
                                            `qc_material_id`, 
                                            `item_description`,
                                            `received_qty`,
                                            `unit`,
                                            `received_qty_in_kg`,
                                            `batch_no`,
                                            `supplier_invoice_no`,
                                            `invoice_date`,
                                            `total_accepted_qty`,
                                            `accepted_qty`,
                                            `total_rejected_qty`,
                                            `rejected`,
                                            `rejection_reason`
                                        ) 
                                VALUES ($vals)";        
    
                                $stmt = $this->db->prepare($sql2);
                                $stmt->execute();               
                            }
                            }
    
                            
                        }
                                        
                            $this->tpl->set('message', 'Qc Material Inward form edited successfully!');   
                            header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/qcmaterialinward');
                           
                            } catch (Exception $exc) {
                             //edit failed option
                            $this->tpl->set('message', 'Failed to edit, try again!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/qc_material_inward.php'));
                            }
    
                    break;
                    
                case 'addsubmit':
                    
                    if (isset($crud_string)) {
                         
                        $form_post_data = $dbutil->arrFltr($_POST);
                        // $dispatch_date=!empty($form_post_data['invoice_date_'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
                        // $delivery_date=!empty($form_post_data['DeliveryDate'])?date("Y-m-d", strtotime($form_post_data['DeliveryDate'])):'';
                        // "'" . $dispatch_date . "'," .
                    //     // $purchase_indentno=$form_post_data['purchaseindent_ID'];
                    //     echo '<pre>';
                    //    print_r($form_post_data); die;
                        
                                $val =  "'" . $form_post_data['mrn_no'] . "'," .                                  
                                        "'" . $form_post_data['purchaseorder'] . "'," .
                                        "'" . $form_post_data['Store'] . "'," .
                                        "'" . $form_post_data['Purchase_Indent_No'] . "'," .
                                        "'" . $form_post_data['Supplier_Name'] . "'," .
                                        "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                        "'" .  $this->ses->get('user')['ID'] . "'";
    
                             $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "qc_materialinward`
                                            ( 
                                            `mrn_no`,
                                            `purchaseorder`,
                                            `Store`,
                                            `purchase_indentNo`,
                                            `Supplier_Name`,
                                            `entity_ID`,
                                            `users_ID`
                                            ) 
                                    VALUES ( $val )";
                                    $stmt = $this->db->prepare($sql);       
                        if ($stmt->execute()) { 
                        
                        $lastInsertedID = $this->db->lastInsertId();
                          
                    
                      FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
    
                        $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                                $item_description =$form_post_data['item_description_' . $entry_count]; 
                                $received_qty =$form_post_data['received_qty_' . $entry_count]; 
                                $unit =$form_post_data['unit_' . $entry_count];
                                $received_qty_in_kg =$form_post_data['received_qty_in_kg_' . $entry_count];								
                                $batch_no =$form_post_data['batch_no_' . $entry_count];
                                $supplier_invoice_no =$form_post_data['supplier_invoice_no_' . $entry_count];
                                $total_accepted_qty =$form_post_data['total_accepted_qty_' . $entry_count];
                                $accepted_qty =$form_post_data['accepted_qty_' . $entry_count];
                                $total_rejected_qty =$form_post_data['total_rejected_qty_' . $entry_count];
                                $rejected =$form_post_data['rejected_' . $entry_count];
                                $rejection_reason =$form_post_data['rejection_reason_' . $entry_count];
                                // $invoice =$form_post_data['invoice_date_' . $entry_count];
                                
                                
                            
                                
                               
                                
                                $vals = "'" . $lastInsertedID . "'," .
                                        "'" . $item_description . "'," .
                                        "'" . $received_qty . "'," .
                                        "'" . $unit . "'," .
                                        "'" . $received_qty_in_kg . "'," .
                                        "'" . $batch_no . "'," .
                                        "'" . $supplier_invoice_no . "'," .
                                        "'" . $invoice_date . "'," .
                                        "'" . $total_accepted_qty . "'," .
                                        "'" . $accepted_qty . "'," .
                                        "'" . $total_rejected_qty . "'," .
                                        "'" . $rejected . "'," .
                                        "'" . $rejection_reason . "'" ;   
                          $sql2 = "INSERT INTO $qc_detail_tab
                                        ( 
                                            `qc_material_id`, 
                                            `item_description`,
                                            `received_qty`,
                                            `unit`,
                                            `received_qty_in_kg`,
                                            `batch_no`,
                                            `supplier_invoice_no`,
                                            `invoice_date`,
                                            `total_accepted_qty`,
                                            `accepted_qty`,
                                            `total_rejected_qty`,
                                            `rejected`,
                                            `rejection_reason`
                                        ) 
                                VALUES ($vals)";
                                $stmt = $this->db->prepare($sql2);
                            $stmt->execute();  
                           
                               
                            }           
                            
                            
                          
                        }
                                                           
                        $this->tpl->set('mode', 'add');
                        $this->tpl->set('message', '- Success -');
                        header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/qcmaterialinward');
                     } else {
                            //edit option
                            //if submit failed to insert form
                            $this->tpl->set('message', 'Failed to submit!');
                            $this->tpl->set('FmData', $form_post_data);
                            $this->tpl->set('content', $this->tpl->fetch('factory/form/qc_material_inward.php'));
                     }
                     
                    break;
    
                case 'add':
                    $this->tpl->set('mode', 'add');
                    $this->tpl->set('page_header', 'Store');
                    $MaterialNo=$dbutil->keyGeneration('materialinward','MNO','','MaterialNo');
                    $this->tpl->set('MaterialNo', $MaterialNo);
                    $this->tpl->set('content', $this->tpl->fetch('factory/form/qc_material_inward.php'));
                    break;
    
                default:
                    /*
                     * List form
                     */
                     
                    ////////////////////start//////////////////////////////////////////////
                    
           //bUILD SQL 
            $whereString = '';
            
         $colArr = array(
                "$qc_mast_tab.ID",
                "$qc_mast_tab.mrn_no",
                "$qc_mast_tab.purchaseorder",
               
               
                
                // "$po_master_tab.ID"
    
            );
            
            $this->tpl->set('FmData', $_POST);
            foreach($_POST as $k=>$v){
                if(strpos($k,'^')){
                    unset($_POST[$k]);
                }
                $_POST[str_replace('^','_',$k)] = $v;
            }
            $PD=$_POST;
            if($_POST['list']!=''){
                $this->tpl->set('FmData', NULL);
                $PD=NULL;
            }
    
            IF (count($PD) >= 2) {
                $wsarr = array();
                foreach ($colArr as $colNames) {
    
                if (strpos($colNames, 'DATE') !== false) {
                    list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
                }else {
                    $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
                }
    
                  if ('' != $x) {
                   $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                    }
                }
                
           IF (count($wsarr) >= 1) {
                $whereString = ' AND '. implode(' AND ', $wsarr);
            }
           } else {
             $whereString ="ORDER BY $qc_mast_tab.ID DESC";
           }
           
        $sql = "SELECT "
                    . implode(',',$colArr)
                    . " FROM $qc_mast_tab "
                    . " WHERE "
                    . " $qc_mast_tab.entity_ID = $entityID"
                    . " $whereString";  
            
         
    
                $results_per_page = 50;     
            
                if(isset($PD['pageno'])){$page=$PD['pageno'];}
                else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
                else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
                else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
                else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
                else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
                else{$page=1;} 
            /*
             * SET DATA TO TEMPLATE
                        */
           $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
         
         
            $this->tpl->set('table_columns_label_arr', array('ID','Material NO','Purchase Order No'));
            
            /*
             * selectColArr for filter form
             */
            
            $this->tpl->set('selectColArr',$colArr);
            // $this->tpl->set('dcpdf','Generate Pdf');            
            /*
             * set pagination template
             */
            $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
                   
            //////////////////////close//////////////////////////////////////  
                     
                    include_once $this->tpl->path . '/factory/form/qc_material_inward_crud_form.php';
                    $cus_form_data = Form_Elements::data($this->crg);
                    include_once 'util/crud3_1.php';
                    new Crud3($this->crg, $cus_form_data);
                    break;
            }
    
        ///////////////Use different template////////////////////
        // $this->tpl->set('master_layout', 'layout_chart.php'); 
        $this->tpl->set('master_layout', 'layout_datepicker.php'); 
          // $this->tpl->set('master_layout', 'layout_datepicker.php'); 
        ///////////////////////////////////////////////////////////////////
        //////////////////////////////on access condition failed then /////
        ///////////////////////////////////////////////////////////////////
     } else {
             if ($this->ses->get('user')['ID']) {
                 $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
             } else {
                 header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
             }
         }
    } 


////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
/////////////////     Raw Material Issue form  

function rawmaterialissue(){
     
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
         
        /////////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied///////////
        /////////////////////////////////////////////////////////////////
        
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
        
        include_once 'util/genUtil.php';
        $util = new GenUtil();
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
        $unit_table = $this->crg->get('table_prefix') . 'unit';
        $po_detail_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
        $po_master_tab = $this->crg->get('table_prefix') . 'purchaseorder';
        $supplier_tab = $this->crg->get('table_prefix') . 'supplier';
        $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
        $indent_det_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
        $state_tab = $this->crg->get('table_prefix') . 'state';
        $unit_tab = $this->crg->get('table_prefix') . 'unit';
        $material_inward_tab = $this->crg->get('table_prefix') . 'material_inward';
        $material_inward_detail_tab = $this->crg->get('table_prefix') . 'material_inward_detail';
        $rawmeterial_issue_tab = $this->crg->get('table_prefix') . 'rawmeterial_issue';
        $rawmeterial_issue_det_tab = $this->crg->get('table_prefix') . 'rawmeterial_issue_detail';
        
        //indent table data
       
        $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1 and $indent_master_tab.PI_Status=1 ORDER BY $indent_master_tab.ID DESC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $indent_data  = $stmt->fetchAll();	
        $this->tpl->set('indent_data', $indent_data);

         //perchase Order table data
       
         $sql = "SELECT ID,MaterialNo FROM $material_inward_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $material_inward_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('material_inward_tab_data', $material_inward_tab_data);

         //perchase Order table data
       
         $sql = "SELECT ID,PurchaseOrderNo,purchaseindent_ID FROM $po_master_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $po_master_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('po_master_tab', $po_master_tab_data);
        
        //supplier table data
       
        $sql = "SELECT ID,SupplierName FROM $supplier_tab ORDER BY $supplier_tab.SupplierName ASC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $supplier_data  = $stmt->fetchAll();	
        $this->tpl->set('supplier_data', $supplier_data);
        
        //rawmaterial table data
       
        $sql = "SELECT ID,RMName FROM $rawmaterial_table";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $rawmaterial_data  = $stmt->fetchAll();	
        $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
        //unit table data
       
        $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
        $stmt = $this->db->prepare($pdt_sql);            
        $stmt->execute();
        $unit_data  = $stmt->fetchAll();	
        $this->tpl->set('unit_data', $unit_data);
 
        $this->tpl->set('page_title', 'Raw Material Issue');	          
        $this->tpl->set('page_header', 'Store');
        
        //Add Role when u submit the add role form
        $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

        $crud_string = null;

        if (isset($_POST['req_from_list_view'])) {
            $crud_string = strtolower($_POST['req_from_list_view']);
        }              
        
        //Edit submit
        if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
            $crud_string = 'editsubmit';
        }
        
        //Add submit
        if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
            $crud_string = 'addsubmit';
        }
        

        switch ($crud_string) {
             case 'delete':                    
                  $data = trim($_POST['ycs_ID']);
                   
                   
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                   
                }
               
                // $sqlsrr = "SELECT * FROM $po_master_tab WHERE ID=$data";
                // $po_data = $dbutil->getSqlData($sqlsrr); 
                
                // $sqlsrr = "SELECT * FROM  $po_detail_tab WHERE purchaseorder_ID=$data";
                // $podet_data = $dbutil->getSqlData($sqlsrr); 
                
                // $purchase_indentno=(count($po_data)>0)?$po_data[0]['purchaseindent_ID']:'';
                 
                // $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                // $indentdet_data = $dbutil->getSqlData($sqlsrr);
                
                 
                //  if(!empty($purchase_indentno)){
                //      $sql_update="Update $indent_master_tab SET $indent_master_tab.PI_Status=1 WHERE  $indent_master_tab.ID=$purchase_indentno";
                //                  $masterstmt1 = $this->db->prepare($sql_update);
                //                  $masterstmt1->execute();
                                 
                //     foreach($podet_data as $k=>$v){
                        
                //         foreach($indentdet_data as $kk=>$value){
                            
                //             if(($value['rawmaterial_ID']==$v['rawmaterial_ID'])){
                                
                //                 $sql_updates="Update $indent_det_tab SET $indent_det_tab.ItemStatus=1,$indent_det_tab.RaisedPOQty=(RaisedPOQty-$v[POQuantity]) WHERE $indent_det_tab.ID=$value[ID]";
                //                 $detstmt1 = $this->db->prepare($sql_updates);
                //               $detstmt1->execute();
                             
                //             }
                            
                //         }
                        
                //     }
                                 
                      
                //  }
                 
                $sqldetdelete="DELETE $rawmeterial_issue_tab,$rawmeterial_issue_det_tab FROM $rawmeterial_issue_tab
                               LEFT JOIN  $rawmeterial_issue_det_tab ON $rawmeterial_issue_tab.ID=$rawmeterial_issue_det_tab.po_no_id 
                               WHERE $rawmeterial_issue_tab.ID=$data";  
                               
                $stmt = $this->db->prepare($sqldetdelete);            
                    
                    if($stmt->execute()){
                    $this->tpl->set('message', 'Raw Material Issue deleted successfully');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/rawmaterialissue');
                    // $this->tpl->set('label', 'List');
                    // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    } 
                    
        break;
            case 'view':                    
                $data = trim($_POST['ycs_ID']);
             
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to view!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', 'view');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                //  $sqlsrr = "SELECT  $po_master_tab.*,
                //                    $po_detail_tab.*,
                //                    $rawmaterial_table.RMName,
                //                    $supplier_tab.SupplierName,
                //                    $supplier_tab.AddressLine1,
                //                    $supplier_tab.AddressLine2,
                //                    $supplier_tab.City,
                //                    $state_tab.StateName,
                //                    $unit_table.UnitName
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";
                // $indent_data = $dbutil->getSqlData($sqlsrr); 
                $sqlsrr="SELECT * FROM $rawmeterial_issue_tab,$rawmeterial_issue_det_tab
                WHERE  $rawmeterial_issue_tab.ID = $rawmeterial_issue_det_tab.po_no_id
                AND $rawmeterial_issue_tab.ID = $data";   
                
                $indent_data = $dbutil->getSqlData($sqlsrr);               
              
                
                        
               
                
                
                //edit option     
                $this->tpl->set('message', 'You can view Raw Material Issue form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/rawmaterial_issuse_form.php'));                    
                break;
            
            case 'edit':                    
                $data = trim($_POST['ycs_ID']);
                $mode='edit';
                if(isset($_SESSION['ycs_ID']))
                {
                    $data = trim($_SESSION['ycs_ID']);
                    unset($_SESSION['ycs_ID']);
                    $mode='Confirm';
                }
           // var_dump($data);
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to edit!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', $mode);
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                // $sqlsrr = "SELECT  *,$enquiry_tab.PONo,
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";


               $sqlsrr="SELECT * FROM $rawmeterial_issue_tab,$rawmeterial_issue_det_tab
                WHERE  $rawmeterial_issue_tab.ID = $rawmeterial_issue_det_tab.po_no_id
                AND $rawmeterial_issue_tab.ID = $data";         

                $indent_data = $dbutil->getSqlData($sqlsrr);               
                $indentsel_data  = $stmt->fetchAll();	
                $this->tpl->set('indent_data', $indentsel_data);
            
                //edit option     
                $this->tpl->set('message', 'You can edit Raw Material Issue form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/rawmaterial_issuse_form.php'));                    
                break;
            
            case 'editsubmit':             
                $data = trim($_POST['ycs_ID']);
                
                //mode of form submit
                $this->tpl->set('mode', 'edit');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);

                //Post data
                include_once 'util/genUtil.php';
                $util = new GenUtil();
                $form_post_data = $util->arrFltr($_POST);

                //        echo '<pre>';
                //    print_r($form_post_data); die;
                
                // $sqldet_del = "DELETE FROM $po_detail_tab WHERE purchaseorder_ID=$data";
                // $stmt = $this->db->prepare($sqldet_del);
                // $stmt->execute();   
                        
                        try{
                            
                                                    
                    
        
                        
                        $store= $form_post_data['store'];
                        $po_no= $form_post_data['po_no'];
                        $work_order_no= $form_post_data['work_order_no'];
                        $person_name= $form_post_data['person_name'];
                        $product_name= $form_post_data['product_name'];  
                        $product_number= $form_post_data['product_number'];
                        $process= $form_post_data['process'];
                        $product_size= $form_post_data['product_size'];
                        $thickness= $form_post_data['thickness'];
                        $color= $form_post_data['color'];
                        $design= $form_post_data['design']; 
                        $quantity= $form_post_data['quantity']; 
                        $completed_on= $form_post_data['completed_on']; 
                        $lay_up_sequence= $form_post_data['lay_up_sequence'];   
                        $details= $form_post_data['details'];  
                        $remarks= $form_post_data['remarks']; 
                        $statuss= $form_post_data['statuss'];  
                        $created_by= $form_post_data['created_by']; 


                        $sql2 = "UPDATE $rawmeterial_issue_tab set

                        store='$store',
                        po_no='$po_no',
                        work_order_no='$work_order_no',
                        person_name='$person_name',
                        product_name='$product_name',
                        product_number='$product_number',
                        process='$process',
                        product_size='$product_size',
                        thickness='$thickness',
                        color='$color',
                        design='$design',
                        quantity='$quantity',
                        completed_on='$completed_on',
                        lay_up_sequence='$lay_up_sequence',
                        details='$details',
                        remarks='$remarks',
                        statuss='$statuss',
                        created_by='$created_by'

                         WHERE ID=$data";	
                        
                        $stmt1 = $this->db->prepare($sql2);
                        $stmt1->execute()     ;
                                // $stmt->execute();
                        // $sql_update="Update $material_inward_tab SET  MaterialNo='$MaterialNo',
                        // PurchaseNO='$PurchaseNO',
                        // Store='$Store',
                        // Purchase_Indent_No='$Purchase_Indent_No',
                        // Supplier_Name='$Supplier_Name'
                                                                
                                                        //  WHERE  ID=$data";      
                        // $stmt1 = $this->db->prepare($sql_update);
                        // $sql3 = "DELETE FROM $material_inward_detail_tab WHERE proforma_invoice_ID=$data";
                        //  $stmt3 = $this->db->prepare($sql3);

                        $sql3 = "DELETE FROM $rawmeterial_issue_det_tab WHERE po_no_id=$data";
                        $stmt3 = $this->db->prepare($sql3);

                    if($stmt3->execute()){
                    
                    FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                            
                            
                            
                            
                            // $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                            $raw_materials =$form_post_data['raw_materials_' . $entry_count];  
                            $request_quantity =$form_post_data['request_quantity_' . $entry_count];
                            $uom =$form_post_data['uom_' . $entry_count];								
                            $issued_qty =$form_post_data['issued_qty_' . $entry_count];
                            $excess_qty =$form_post_data['excess_qty_' . $entry_count];
                           
                            if(!empty($raw_materials) && !empty($request_quantity)){
                          

                                    $vals = "'" . $data . "'," .
                                   
                                    "'" . $raw_materials . "'," .
                                    "'" . $request_quantity . "'," .
                                    "'" . $uom . "'," .
                                    "'" . $issued_qty . "',".
                                    "'" . $excess_qty . "'";

                            $sql2 = "INSERT INTO $rawmeterial_issue_det_tab
                                    ( 

                                        `po_no_id`, 
                                        `raw_materials`,
                                        `request_quantity`,
                                        `uom`,
                                        `issued_qty`,
                                        `excess_qty`
                                        
                                    ) 
                            VALUES ($vals)";        

                            $stmt = $this->db->prepare($sql2);
                            $stmt->execute();               
                        }
                        }  

                        
                    }
                                    
                        $this->tpl->set('message', 'Raw Material Issue form edited successfully!');   
                        header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/rawmaterialissue');
                       
                        } catch (Exception $exc) {
                         //edit failed option
                        $this->tpl->set('message', 'Failed to edit, try again!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/rawmaterial_issuse_form.php'));
                        }

                break;
                
            case 'addsubmit':
                
                if (isset($crud_string)) {
                     
                    $form_post_data = $dbutil->arrFltr($_POST);
                    // $dispatch_date=!empty($form_post_data['invoice_date_'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
                     $completed_on=!empty($form_post_data['completed_on'])?date("Y-m-d", strtotime($form_post_data['completed_on'])):'';
                    // "'" . $dispatch_date . "'," .
                    // $purchase_indentno=$form_post_data['purchaseindent_ID'];
                //     echo '<pre>';
                //    print_r($form_post_data); die;
                    
                            $val =  "'" . $form_post_data['store'] . "'," .                                  
                                    "'" . $form_post_data['po_no'] . "'," .
                                    "'" . $form_post_data['work_order_no'] . "'," .
                                    "'" . $form_post_data['person_name'] . "'," .
                                    "'" . $form_post_data['product_name'] . "'," .
                                    "'" . $form_post_data['product_number'] . "'," .
                                    "'" . $form_post_data['process'] . "'," .
                                    "'" . $form_post_data['product_size'] . "'," .
                                    "'" . $form_post_data['thickness'] . "'," .
                                    "'" . $form_post_data['color'] . "'," .
                                    "'" . $form_post_data['design'] . "'," .
                                    "'" . $form_post_data['quantity'] . "'," .
                                    // "'" . $form_post_data['completed_on'] . "'," .
                                    "'" . $completed_on . "'," .
                                    "'" . $form_post_data['lay_up_sequence'] . "'," .
                                    "'" . $form_post_data['details'] . "'," .
                                    "'" . $form_post_data['remarks'] . "'," .
                                    "'" . $form_post_data['statuss'] . "'," .
                                    "'" . $form_post_data['created_by'] . "'," .
                                    "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                    "'" .  $this->ses->get('user')['ID'] . "'";

                       $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "rawmeterial_issue`
                                        ( 
                                        `store`,
                                        `po_no`,
                                        `work_order_no`,
                                        `person_name`,
                                        `product_name`,
                                        `product_number`,
                                        `process`,
                                        `product_size`,
                                        `thickness`,
                                        `color`,
                                        `design`,
                                        `quantity`,
                                        `completed_on`,
                                        `lay_up_sequence`,
                                        `details`,
                                        `remarks`,
                                        `statuss`,
                                        `created_by`,
                                        `entity_ID`,
                                        `users_ID`
                                        ) 
                                VALUES ( $val )";
                                $stmt = $this->db->prepare($sql);       
                    if ($stmt->execute()) { 
                    
                    $lastInsertedID = $this->db->lastInsertId();  
                  FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {

                            //  $invoice_date=!empty($form_post_data['completed_on_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['completed_on_'. $entry_count])):'';
                            $raw_materials =$form_post_data['raw_materials_' . $entry_count]; 
                            $request_quantity =$form_post_data['request_quantity_' . $entry_count]; 
                            $uom =$form_post_data['uom_' . $entry_count];
                            $issued_qty =$form_post_data['issued_qty_' . $entry_count];
                            $excess_qty =$form_post_data['excess_qty_' . $entry_count];								
                            // $unit =$form_post_data['unit_' . $entry_count];
                            // $receivedqt =$form_post_data['received_qt_in_kg_' . $entry_count];
                            // $batch =$form_post_data['batch_no_' . $entry_count];
                            // $costunit =$form_post_data['cost_unit_' . $entry_count];
                            // $total =$form_post_data['total_' . $entry_count];
                            // $supplier =$form_post_data['supplier_invoice_no_' . $entry_count];
                            // $invoice =$form_post_data['invoice_date_' . $entry_count];
                            
                            
                        
                            
                           
                            
                            $vals = "'" . $lastInsertedID . "'," .
                                    "'" . $raw_materials . "'," .
                                    "'" . $request_quantity . "'," .
                                    "'" . $uom . "'," .
                                    "'" . $issued_qty . "'," .
                                    "'" . $excess_qty . "'";
                                    // "'" . $unit . "'," .
                                    // "'" . $receivedqt . "'," .
                                    // "'" . $batch . "'," .
                                    // "'" . $costunit . "'," .
                                    // "'" . $total . "'," .
                                    // "'" . $supplier . "'," .
                                    // "'" . $invoice_date . "'" ;   
                      $sql2 = "INSERT INTO $rawmeterial_issue_det_tab
                                    ( 
                                        `po_no_id`, 
                                        `raw_materials`,
                                        `request_quantity`,
                                        `uom`,
                                        `issued_qty`,
                                        `excess_qty`
                                       
                                    ) 
                            VALUES ($vals)";
                            $stmt = $this->db->prepare($sql2);
                        $stmt->execute();                           
                       
                           
                        }   
                        
                        
                      
                    }
                                                       
                    $this->tpl->set('mode', 'add');
                    $this->tpl->set('message', '- Success -');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/rawmaterialissue');
                 } else {
                        //edit option
                        //if submit failed to insert form
                        $this->tpl->set('message', 'Failed to submit!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/rawmaterial_issuse_form.php'));
                 }
                 
                break;

            case 'add':
                $this->tpl->set('mode', 'add');
                $this->tpl->set('page_header', 'Store');
                $MaterialNo=$dbutil->keyGeneration('materialinward','MNO','','MaterialNo');
                $this->tpl->set('MaterialNo', $MaterialNo);
                $this->tpl->set('content', $this->tpl->fetch('factory/form/rawmaterial_issuse_form.php'));
                break;

            default:
                /*
                 * List form
                 */
                 
                ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
     $colArr = array(
            "$rawmeterial_issue_tab.ID",
            "$rawmeterial_issue_tab.po_no",
            "$rawmeterial_issue_tab.work_order_no",
            "$rawmeterial_issue_tab.person_name"
           
            
            // "$po_master_tab.ID"

        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

            if (strpos($colNames, 'DATE') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
            }else {
                $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
            }

              if ('' != $x) {
               $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
       IF (count($wsarr) >= 1) {
            $whereString = ' AND '. implode(' AND ', $wsarr);
        }
       } else {
         $whereString ="ORDER BY $rawmeterial_issue_tab.ID DESC";
       }
       
    $sql = "SELECT "
                . implode(',',$colArr)
                . " FROM $rawmeterial_issue_tab "
                . " WHERE "
                . " $rawmeterial_issue_tab.entity_ID = $entityID"
                . " $whereString"; 
        
     

            $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
        /*
         * SET DATA TO TEMPLATE
                    */
       $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
     
     
        $this->tpl->set('table_columns_label_arr', array('ID','PO Number','Work Order Number','Persone Name'));
        
        /*
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
        // $this->tpl->set('dcpdf','Generate Pdf');            
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
                 
                include_once $this->tpl->path . '/factory/form/rawmaterial_issue_crud_form.php';
                $cus_form_data = Form_Elements::data($this->crg);
                include_once 'util/crud3_1.php';
                new Crud3($this->crg, $cus_form_data);
                break;
        }

    ///////////////Use different template////////////////////
    // $this->tpl->set('master_layout', 'layout_chart.php'); 
    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
    ///////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then /////
    ///////////////////////////////////////////////////////////////////
 } else {
         if ($this->ses->get('user')['ID']) {
             $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
         } else {
             header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
         }
     }
} 

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//////////////////////////  stock return
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////




function stockadjustment(){
     
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
         
        /////////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied///////////
        /////////////////////////////////////////////////////////////////
        
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
        
        include_once 'util/genUtil.php';
        $util = new GenUtil();
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
        $unit_table = $this->crg->get('table_prefix') . 'unit';
        $po_detail_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
        $po_master_tab = $this->crg->get('table_prefix') . 'purchaseorder';
        $supplier_tab = $this->crg->get('table_prefix') . 'supplier';
        $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
        $indent_det_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
        $state_tab = $this->crg->get('table_prefix') . 'state';
        $unit_tab = $this->crg->get('table_prefix') . 'unit';
        $material_inward_tab = $this->crg->get('table_prefix') . 'material_inward';
        $material_inward_detail_tab = $this->crg->get('table_prefix') . 'material_inward_detail';
        $rawmeterial_issue_tab = $this->crg->get('table_prefix') . 'rawmeterial_issue';
        $rawmeterial_issue_det_tab = $this->crg->get('table_prefix') . 'rawmeterial_issue_detail';
        $stockreturn_mast_tab = $this->crg->get('table_prefix') . 'stockreturn_mast';
        $stockreturn_detail_tab = $this->crg->get('table_prefix') . 'stockreturn_detail';
        $stockadjustment_tab = $this->crg->get('table_prefix') . 'stockadjustment';
        
        //indent table data
       
        $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1 and $indent_master_tab.PI_Status=1 ORDER BY $indent_master_tab.ID DESC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $indent_data  = $stmt->fetchAll();	
        $this->tpl->set('indent_data', $indent_data);

         //perchase Order table data
       
         $sql = "SELECT ID,MaterialNo FROM $material_inward_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $material_inward_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('material_inward_tab_data', $material_inward_tab_data);

         //perchase Order table data
       
         $sql = "SELECT ID,PurchaseOrderNo,purchaseindent_ID FROM $po_master_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $po_master_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('po_master_tab', $po_master_tab_data);
        
        //supplier table data
       
        $sql = "SELECT ID,SupplierName FROM $supplier_tab ORDER BY $supplier_tab.SupplierName ASC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $supplier_data  = $stmt->fetchAll();	
        $this->tpl->set('supplier_data', $supplier_data);
        
        //rawmaterial table data
       
        $sql = "SELECT ID,RMName FROM $rawmaterial_table";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $rawmaterial_data  = $stmt->fetchAll();	
        $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
        //unit table data
       
        $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
        $stmt = $this->db->prepare($pdt_sql);            
        $stmt->execute();
        $unit_data  = $stmt->fetchAll();	
        $this->tpl->set('unit_data', $unit_data);
 
        $this->tpl->set('page_title', 'Stock Adjustment');	          
        $this->tpl->set('page_header', 'Store');
        
        //Add Role when u submit the add role form
        $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

        $crud_string = null;

        if (isset($_POST['req_from_list_view'])) {
            $crud_string = strtolower($_POST['req_from_list_view']);
        }              
        
        //Edit submit
        if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
            $crud_string = 'editsubmit';
        }
        
        //Add submit
        if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
            $crud_string = 'addsubmit';
        }
        

        switch ($crud_string) {
             case 'delete':                    
                  $data = trim($_POST['ycs_ID']);
                   
                   
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                   
                }
               
                // $sqlsrr = "SELECT * FROM $po_master_tab WHERE ID=$data";
                // $po_data = $dbutil->getSqlData($sqlsrr); 
                
                // $sqlsrr = "SELECT * FROM  $po_detail_tab WHERE purchaseorder_ID=$data";
                // $podet_data = $dbutil->getSqlData($sqlsrr); 
                
                // $purchase_indentno=(count($po_data)>0)?$po_data[0]['purchaseindent_ID']:'';
                 
                // $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                // $indentdet_data = $dbutil->getSqlData($sqlsrr);
                
                 
                //  if(!empty($purchase_indentno)){
                //      $sql_update="Update $indent_master_tab SET $indent_master_tab.PI_Status=1 WHERE  $indent_master_tab.ID=$purchase_indentno";
                //                  $masterstmt1 = $this->db->prepare($sql_update);
                //                  $masterstmt1->execute();
                                 
                //     foreach($podet_data as $k=>$v){
                        
                //         foreach($indentdet_data as $kk=>$value){
                            
                //             if(($value['rawmaterial_ID']==$v['rawmaterial_ID'])){
                                
                //                 $sql_updates="Update $indent_det_tab SET $indent_det_tab.ItemStatus=1,$indent_det_tab.RaisedPOQty=(RaisedPOQty-$v[POQuantity]) WHERE $indent_det_tab.ID=$value[ID]";
                //                 $detstmt1 = $this->db->prepare($sql_updates);
                //               $detstmt1->execute();
                             
                //             }
                            
                //         }
                        
                //     }
                                 
                      
                //  }
                 
                // $sqldetdelete="DELETE $stockreturn_mast_tab,$stockreturn_detail_tab FROM $stockreturn_mast_tab
                //                LEFT JOIN  $stockreturn_detail_tab ON $stockreturn_mast_tab.ID=$stockreturn_detail_tab.stockreturn_id 
                //                WHERE $stockreturn_mast_tab.ID=$data";  

                $sqldetdelete="DELETE $stockadjustment_tab FROM $stockadjustment_tab
                               
                               WHERE $stockadjustment_tab.ID=$data";  
                               
                $stmt = $this->db->prepare($sqldetdelete);            
                    
                    if($stmt->execute()){
                    $this->tpl->set('message', 'Stock Return deleted successfully');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/stockadjustment');
                    // $this->tpl->set('label', 'List');
                    // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    } 
                    
        break;
            case 'view':                    
                $data = trim($_POST['ycs_ID']);
             
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to view!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', 'view');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                //  $sqlsrr = "SELECT  $po_master_tab.*,
                //                    $po_detail_tab.*,
                //                    $rawmaterial_table.RMName,
                //                    $supplier_tab.SupplierName,
                //                    $supplier_tab.AddressLine1,
                //                    $supplier_tab.AddressLine2,
                //                    $supplier_tab.City,
                //                    $state_tab.StateName,
                //                    $unit_table.UnitName
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";
                // $indent_data = $dbutil->getSqlData($sqlsrr); 
               
                // $sqlsrr="SELECT * FROM $stockreturn_mast_tab,$stockreturn_detail_tab
                // WHERE  $stockreturn_mast_tab.ID = $stockreturn_detail_tab.stockreturn_id
                // AND $stockreturn_mast_tab.ID = $data"; 
                
                
                $sqlsrr="SELECT * FROM $stockadjustment_tab
                WHERE   $stockadjustment_tab.ID = $data";        
                
                $indent_data = $dbutil->getSqlData($sqlsrr);               
              
                
                        
               
                
                
                //edit option     
                $this->tpl->set('message', 'You can view Stock Return form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/stockadjustment_form.php'));                    
                break;
            
            case 'edit':                    
                $data = trim($_POST['ycs_ID']);
                $mode='edit';
                if(isset($_SESSION['ycs_ID']))
                {
                    $data = trim($_SESSION['ycs_ID']);
                    unset($_SESSION['ycs_ID']);
                    $mode='Confirm';
                }
           // var_dump($data);
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to edit!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', $mode);
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                // $sqlsrr = "SELECT  *,$enquiry_tab.PONo,
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";


            //    $sqlsrr="SELECT * FROM $stockreturn_mast_tab,$stockreturn_detail_tab
            //     WHERE  $stockreturn_mast_tab.ID = $stockreturn_detail_tab.stockreturn_id
            //     AND $stockreturn_mast_tab.ID = $data";         

            $sqlsrr="SELECT * FROM $stockadjustment_tab
                WHERE   $stockadjustment_tab.ID = $data"; 

                $indent_data = $dbutil->getSqlData($sqlsrr);               
                $indentsel_data  = $stmt->fetchAll();	
                $this->tpl->set('indent_data', $indentsel_data);
            
                //edit option     
                $this->tpl->set('message', 'You can edit Stock Return form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/stockadjustment_form.php'));                   
                break;
            
            case 'editsubmit':             
                $data = trim($_POST['ycs_ID']);
                
                //mode of form submit
                $this->tpl->set('mode', 'edit');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);

                //Post data
                include_once 'util/genUtil.php';
                $util = new GenUtil();
                $form_post_data = $util->arrFltr($_POST);

                //        echo '<pre>';
                //    print_r($form_post_data); die;
                
                // $sqldet_del = "DELETE FROM $po_detail_tab WHERE purchaseorder_ID=$data";
                // $stmt = $this->db->prepare($sqldet_del);
                // $stmt->execute();   
                        
                        try{
                            
                                                    
                    
        
                        
                        $store= $form_post_data['store'];
                        $stock_return_no= $form_post_data['stock_return_no'];
                        $item_type= $form_post_data['item_type'];
                        $item_name= $form_post_data['item_name'];
                        $batch_no= $form_post_data['batch_no'];  
                        $availabel_qty= $form_post_data['availabel_qty'];
                        $adjustment_type= $form_post_data['adjustment_type'];
                        $quantity_to_be_adjust= $form_post_data['quantity_to_be_adjust'];
                        $reasone_for_adjust= $form_post_data['reasone_for_adjust'];
                        $comment= $form_post_data['comment'];
                        // $design= $form_post_data['design']; 
                        // $quantity= $form_post_data['quantity']; 
                        // $completed_on= $form_post_data['completed_on']; 
                        // $lay_up_sequence= $form_post_data['lay_up_sequence'];   
                        // $details= $form_post_data['details'];  
                        // $remarks= $form_post_data['remarks'];  
                        // $created_by= $form_post_data['created_by']; 


                       $sql2 = "UPDATE $stockadjustment_tab set store='$store',
                                                                    stock_return_no = '$stock_return_no',
                                                                    item_type = '$item_type',
                                                                    item_name = '$item_name',
                                                                    batch_no = '$batch_no',
                                                                    availabel_qty = '$availabel_qty',
                                                                    adjustment_type = '$adjustment_type',
                                                                    quantity_to_be_adjust = '$quantity_to_be_adjust',
                                                                    reasone_for_adjust = '$reasone_for_adjust',
                                                                    comment = '$comment'
                                                                    WHERE ID = $data";	
                        
                        $stmt = $this->db->prepare($sql2);     
                        $stmt->execute();               
                                // $stmt->execute();
                        // $sql_update="Update $material_inward_tab SET  MaterialNo='$MaterialNo',
                        // PurchaseNO='$PurchaseNO',
                        // Store='$Store',
                        // Purchase_Indent_No='$Purchase_Indent_No',
                        // Supplier_Name='$Supplier_Name'
                                                                
                                                        //  WHERE  ID=$data";      
                        // $stmt1 = $this->db->prepare($sql_update);
                        // $sql3 = "DELETE FROM $materibal_inward_detail_tab WHERE proforma_invoice_ID=$data";
                        //  $stmt3 = $this->db->prepare($sql3);

                    //     $sql3 = "DELETE FROM $stockreturn_detail_tab WHERE stockreturn_id=$data";
                    //     $stmt3 = $this->db->prepare($sql3);

                    // if($stmt3->execute()){
                    
                    // FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {
                            
                            
                            
                            
                    //         // $invoice_date=!empty($form_post_data['invoice_date_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['invoice_date_'. $entry_count])):'';
                    //         $raw_material = $form_post_data['raw_material_' . $entry_count];  
                    //         $size = $form_post_data['size_' . $entry_count];
                    //         $unit = $form_post_data['unit_' . $entry_count];								
                    //         $qty_issued = $form_post_data['qty_issued_' . $entry_count];
                    //         $batch_no = $form_post_data['batch_no_' . $entry_count];
                    //         $total_qty_retn = $form_post_data['total_qty_retn_' . $entry_count];								
                    //         $qty_return = $form_post_data['qty_return_' . $entry_count];
                           
                    //         if(!empty($raw_material) && !empty($size)){
                          

                    //                 $vals = "'" . $data . "'," .
                                   
                    //                 "'" . $raw_material . "'," .
                    //                 "'" . $size . "'," .
                    //                 "'" . $unit . "'," .
                    //                 "'" . $qty_issued . "'," .
                    //                 "'" . $batch_no . "'," .
                    //                 "'" . $total_qty_retn . "'," .
                                    
                    //                 "'" . $qty_return . "'";

                    //         $sql2 = "INSERT INTO $stockreturn_detail_tab
                    //                 ( 

                    //                     `stockreturn_id`, 
                    //                     `raw_material`,
                    //                     `size`,
                    //                     `unit`,
                    //                     `qty_issued`,
                    //                     `batch_no`,
                    //                     `total_qty_retn`,
                    //                     `qty_return`
                                       
                                        
                    //                 ) 
                    //         VALUES ($vals)";        

                    //         $stmt = $this->db->prepare($sql2);
                    //         $stmt->execute();               
                    //     }
                    //     }  

                        
                    // }
                                    
                        $this->tpl->set('message', 'Stock Return form edited successfully!');   
                        header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/stockadjustment');
                       
                        } catch (Exception $exc) {
                         //edit failed option
                        $this->tpl->set('message', 'Failed to edit, try again!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/stockadjustment_form.php'));
                        }

                break;
                
            case 'addsubmit':
                
                if (isset($crud_string)) {
                     
                    $form_post_data = $dbutil->arrFltr($_POST);
                    // $dispatch_date=!empty($form_post_data['invoice_date_'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
                    //  $completed_on=!empty($form_post_data['completed_on'])?date("Y-m-d", strtotime($form_post_data['completed_on'])):'';
                    // "'" . $dispatch_date . "'," .
                    // $purchase_indentno=$form_post_data['purchaseindent_ID'];
                //     echo '<pre>';
                //    print_r($form_post_data); die;
                    
                            $val =  "'" . $form_post_data['store'] . "'," .                                  
                                    "'" . $form_post_data['stock_return_no'] . "'," .
                                    "'" . $form_post_data['item_type'] . "'," .
                                    "'" . $form_post_data['item_name'] . "'," .
                                    "'" . $form_post_data['batch_no'] . "'," .
                                    "'" . $form_post_data['availabel_qty'] . "'," .
                                    "'" . $form_post_data['adjustment_type'] . "'," .
                                    "'" . $form_post_data['quantity_to_be_adjust'] . "'," .
                                    "'" . $form_post_data['reasone_for_adjust'] . "'," .
                                    "'" . $form_post_data['comment'] . "'," .
                                    // "'" . $form_post_data['design'] . "'," .
                                    // "'" . $form_post_data['quantity'] . "'," .
                                    // "'" . $form_post_data['completed_on'] . "'," .
                                    // "'" . $form_post_data['lay_up_sequence'] . "'," .
                                    // "'" . $form_post_data['details'] . "'," .
                                    // "'" . $form_post_data['remarks'] . "'," .
                                    // "'" . $form_post_data['created_by'] . "'," .
                                    "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                    "'" .  $this->ses->get('user')['ID'] . "'";

                       $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "stockadjustment`
                                        ( 
                                        `store`,
                                        `stock_return_no`,
                                        `item_type`,
                                        `item_name`,
                                        `batch_no`,
                                        `availabel_qty`,
                                        `adjustment_type`,
                                        `quantity_to_be_adjust`,
                                        `reasone_for_adjust`,
                                        `comment`,
                                        
                                        `entity_ID`,
                                        `users_ID`
                                        ) 
                                VALUES ( $val )";
                                $stmt = $this->db->prepare($sql);     
                                $stmt->execute();  
                    // if ($stmt->execute()) { 
                    
                //     $lastInsertedID = $this->db->lastInsertId();  
                //   FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {

                //             //  $invoice_date=!empty($form_post_data['completed_on_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['completed_on_'. $entry_count])):'';
                //             $raw_material =$form_post_data['raw_material_' . $entry_count]; 
                //             $size =$form_post_data['size_' . $entry_count]; 
                //             $unit =$form_post_data['unit_' . $entry_count];
                //             $qty_issued =$form_post_data['qty_issued_' . $entry_count];								
                //             $batch_no =$form_post_data['batch_no_' . $entry_count];
                //             $total_qty_retn =$form_post_data['total_qty_retn_' . $entry_count];
                //             $qty_return =$form_post_data['qty_return_' . $entry_count];
                //             // $costunit =$form_post_data['cost_unit_' . $entry_count];
                //             // $total =$form_post_data['total_' . $entry_count];
                //             // $supplier =$form_post_data['supplier_invoice_no_' . $entry_count];
                //             // $invoice =$form_post_data['invoice_date_' . $entry_count];
                            
                            
                        
                            
                           
                            
                //             $vals = "'" . $lastInsertedID . "'," .
                //                     "'" . $raw_material . "'," .
                //                     "'" . $size . "'," .
                //                     "'" . $unit . "'," .
                //                     "'" . $qty_issued . "',".
                //                     "'" . $batch_no . "'," .
                //                     "'" . $total_qty_retn . "'," .
                //                     "'" . $qty_return . "'" ;
                //                     // "'" . $costunit . "'," .
                //                     // "'" . $total . "'," .
                //                     // "'" . $supplier . "'," .
                //                     // "'" . $invoice_date . "'" ;   
                //                          $sql2 = "INSERT INTO $stockreturn_detail_tab
                //                     ( 
                //                         `stockreturn_id`, 
                //                         `raw_material`,
                //                         `size`,
                //                         `unit`,
                //                         `qty_issued`,
                //                         `batch_no`,
                //                         `total_qty_retn`,
                //                         `qty_return`
                                       
                //                     ) 
                //             VALUES ($vals)";
                //             $stmt = $this->db->prepare($sql2);
                //         $stmt->execute();                           
                       
                        
                           
                //         }   
                        
                        
                      
                    // }
                                                       
                    $this->tpl->set('mode', 'add');
                    $this->tpl->set('message', '- Success -');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/stockadjustment');
                 } else {
                        //edit option
                        //if submit failed to insert form
                        $this->tpl->set('message', 'Failed to submit!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/stockadjustment_form.php'));
                 }
                 
                break;

            case 'add':
                $this->tpl->set('mode', 'add');
                $this->tpl->set('page_header', 'Store');
                $stock_return_no=$dbutil->keyGeneration('stockadjustment','SRN','','stock_return_no');
                $this->tpl->set('stock_return_no', $stock_return_no);
                $this->tpl->set('content', $this->tpl->fetch('factory/form/stockadjustment_form.php'));
                break;

            default:
                /*
                 * List form
                 */
                 
                ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
     $colArr = array(
            "$stockadjustment_tab.ID",
            "$stockadjustment_tab.store",
            "$stockadjustment_tab.stock_return_no",
            "$stockadjustment_tab.item_name"
           
            
            // "$po_master_tab.ID"

        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

            if (strpos($colNames, 'DATE') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
            }else {
                $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
            }

              if ('' != $x) {
               $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
       IF (count($wsarr) >= 1) {
            $whereString = ' AND '. implode(' AND ', $wsarr);
        }
       } else {
         $whereString ="ORDER BY $stockadjustment_tab.ID DESC";
       }
       
    $sql = "SELECT "
                . implode(',',$colArr)
                . " FROM $stockadjustment_tab "
                . " WHERE "
                . " $stockadjustment_tab.entity_ID = $entityID"
                . " $whereString"; 
        
     

            $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
        /*
         * SET DATA TO TEMPLATE
                    */
       $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
     
     
        $this->tpl->set('table_columns_label_arr', array('ID','store','Stock Return No','Iterm Type'));
        
        /*
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
        // $this->tpl->set('dcpdf','Generate Pdf');            
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
                 
                include_once $this->tpl->path . '/factory/form/stockadjustment_crud_form.php';
                $cus_form_data = Form_Elements::data($this->crg);
                include_once 'util/crud3_1.php';
                new Crud3($this->crg, $cus_form_data);
                break;
        }

    ///////////////Use different template////////////////////
    // $this->tpl->set('master_layout', 'layout_chart.php'); 
    $this->tpl->set('master_layout', 'layout_datepicker.php'); 
    ///////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then /////
    ///////////////////////////////////////////////////////////////////
 } else {
         if ($this->ses->get('user')['ID']) {
             $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
         } else {
             header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
         }
     }
}

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
//////////////////////////  inventory Transfer

function inventorytransfer(){
     
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
         
        /////////////////////////////////////////////////////////////////
        //////////////////////////////access condition applied///////////
        /////////////////////////////////////////////////////////////////
        
        include_once 'util/DBUTIL.php';
        $dbutil = new DBUTIL($this->crg);
        
        include_once 'util/genUtil.php';
        $util = new GenUtil();
         
        $entityID = $this->ses->get('user')['entity_ID'];
        $userID = $this->ses->get('user')['ID'];
        $rawmaterial_table = $this->crg->get('table_prefix') . 'rawmaterial';
        $unit_table = $this->crg->get('table_prefix') . 'unit';
        $po_detail_tab = $this->crg->get('table_prefix') . 'purchaseorderdetail';
        $po_master_tab = $this->crg->get('table_prefix') . 'purchaseorder';
        $supplier_tab = $this->crg->get('table_prefix') . 'supplier';
        $indent_master_tab = $this->crg->get('table_prefix') . 'purchaseindent';
        $indent_det_tab = $this->crg->get('table_prefix') . 'purchaseindentdetail';
        $state_tab = $this->crg->get('table_prefix') . 'state';
        $unit_tab = $this->crg->get('table_prefix') . 'unit';
        $material_inward_tab = $this->crg->get('table_prefix') . 'material_inward';
        $material_inward_detail_tab = $this->crg->get('table_prefix') . 'material_inward_detail';
        $rawmeterial_issue_tab = $this->crg->get('table_prefix') . 'rawmeterial_issue';
        $rawmeterial_issue_det_tab = $this->crg->get('table_prefix') . 'rawmeterial_issue_detail';
        $stockreturn_mast_tab = $this->crg->get('table_prefix') . 'stockreturn_mast';
        $stockreturn_detail_tab = $this->crg->get('table_prefix') . 'stockreturn_detail';
        $inventory_transfer_tab = $this->crg->get('table_prefix') . 'inventory_transfer';
        $inventory_transfer_detail_tab = $this->crg->get('table_prefix') . 'inventory_transfer_detail';
        
        //indent table data
       
        $sql = "SELECT ID,PurchaseIndentNo FROM $indent_master_tab WHERE $indent_master_tab.Status=1 and $indent_master_tab.PI_Status=1 ORDER BY $indent_master_tab.ID DESC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $indent_data  = $stmt->fetchAll();	
        $this->tpl->set('indent_data', $indent_data);

         //perchase Order table data
       
         $sql = "SELECT ID,MaterialNo FROM $material_inward_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $material_inward_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('material_inward_tab_data', $material_inward_tab_data);

         //perchase Order table data
       
         $sql = "SELECT ID,PurchaseOrderNo,purchaseindent_ID FROM $po_master_tab";
         $stmt = $this->db->prepare($sql);            
         $stmt->execute();
         $po_master_tab_data  = $stmt->fetchAll();	
         $this->tpl->set('po_master_tab', $po_master_tab_data);
        
        //supplier table data
       
        $sql = "SELECT ID,SupplierName FROM $supplier_tab ORDER BY $supplier_tab.SupplierName ASC";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $supplier_data  = $stmt->fetchAll();	
        $this->tpl->set('supplier_data', $supplier_data);
        
        //rawmaterial table data
       
        $sql = "SELECT ID,RMName FROM $rawmaterial_table";
        $stmt = $this->db->prepare($sql);            
        $stmt->execute();
        $rawmaterial_data  = $stmt->fetchAll();	
        $this->tpl->set('rawmaterial_data', $rawmaterial_data);
        
        //unit table data
       
        $pdt_sql = "SELECT ID,UnitName FROM $unit_table";
        $stmt = $this->db->prepare($pdt_sql);            
        $stmt->execute();
        $unit_data  = $stmt->fetchAll();	
        $this->tpl->set('unit_data', $unit_data);
 
        $this->tpl->set('page_title', 'Inventory Transfer');	          
        $this->tpl->set('page_header', 'Store');
        
        //Add Role when u submit the add role form
        $thisPageURL = $this->crg->get('route')['base_path'] . '/' . $this->crg->get('route')['module'] . '/' . $this->crg->get('route')['controller'] . '/' . $this->crg->get('route')['action'];

        $crud_string = null;

        if (isset($_POST['req_from_list_view'])) {
            $crud_string = strtolower($_POST['req_from_list_view']);
        }              
        
        //Edit submit
        if (!empty($_POST['edit_submit_button']) && $_POST['edit_submit_button'] == 'edit') {
            $crud_string = 'editsubmit';
        }
        
        //Add submit
        if (!empty($_POST['add_submit_button']) && $_POST['add_submit_button'] == 'add') {
            $crud_string = 'addsubmit';
        }
        

        switch ($crud_string) {
             case 'delete':                    
                  $data = trim($_POST['ycs_ID']);
                   
                   
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to '.$crud_string.'!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                   
                }
               
                // $sqlsrr = "SELECT * FROM $po_master_tab WHERE ID=$data";
                // $po_data = $dbutil->getSqlData($sqlsrr); 
                
                // $sqlsrr = "SELECT * FROM  $po_detail_tab WHERE purchaseorder_ID=$data";
                // $podet_data = $dbutil->getSqlData($sqlsrr); 
                
                // $purchase_indentno=(count($po_data)>0)?$po_data[0]['purchaseindent_ID']:'';
                 
                // $sqlsrr = "SELECT  * FROM  $indent_det_tab WHERE $indent_det_tab.purchaseindent_ID = '$purchase_indentno'";
                // $indentdet_data = $dbutil->getSqlData($sqlsrr);
                
                 
                //  if(!empty($purchase_indentno)){
                //      $sql_update="Update $indent_master_tab SET $indent_master_tab.PI_Status=1 WHERE  $indent_master_tab.ID=$purchase_indentno";
                //                  $masterstmt1 = $this->db->prepare($sql_update);
                //                  $masterstmt1->execute();
                                 
                //     foreach($podet_data as $k=>$v){
                        
                //         foreach($indentdet_data as $kk=>$value){
                            
                //             if(($value['rawmaterial_ID']==$v['rawmaterial_ID'])){
                                
                //                 $sql_updates="Update $indent_det_tab SET $indent_det_tab.ItemStatus=1,$indent_det_tab.RaisedPOQty=(RaisedPOQty-$v[POQuantity]) WHERE $indent_det_tab.ID=$value[ID]";
                //                 $detstmt1 = $this->db->prepare($sql_updates);
                //               $detstmt1->execute();
                             
                //             }
                            
                //         }
                        
                //     }
                                 
                      
                //  }
                 
                $sqldetdelete="DELETE $inventory_transfer_tab,$inventory_transfer_detail_tab FROM $inventory_transfer_tab
                               LEFT JOIN  $inventory_transfer_detail_tab ON $inventory_transfer_tab.ID=$inventory_transfer_detail_tab.inventory_transfer_ID 
                               WHERE $inventory_transfer_tab.ID=$data";  

               
                               
                $stmt = $this->db->prepare($sqldetdelete);            
                    
                    if($stmt->execute()){
                    $this->tpl->set('message', 'Stock Return deleted successfully');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/inventorytransfer');
                    // $this->tpl->set('label', 'List');
                    // $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    } 
                    
        break;
            case 'view':                    
                $data = trim($_POST['ycs_ID']);
             
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to view!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', 'view');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                //  $sqlsrr = "SELECT  $po_master_tab.*,
                //                    $po_detail_tab.*,
                //                    $rawmaterial_table.RMName,
                //                    $supplier_tab.SupplierName,
                //                    $supplier_tab.AddressLine1,
                //                    $supplier_tab.AddressLine2,
                //                    $supplier_tab.City,
                //                    $state_tab.StateName,
                //                    $unit_table.UnitName
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";
                // $indent_data = $dbutil->getSqlData($sqlsrr); 
               
                $sqlsrr="SELECT * FROM $inventory_transfer_tab,$inventory_transfer_detail_tab
                WHERE  $inventory_transfer_tab.ID = $inventory_transfer_detail_tab.inventory_transfer_ID
                AND $inventory_transfer_tab.ID = $data";          
                
                $indent_data = $dbutil->getSqlData($sqlsrr);               
              
                
                        
               
                
                
                //edit option     
                $this->tpl->set('message', 'You can view Stock Return form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/inventory_transfer_form.php'));                    
                break;
            
            case 'edit':                    
                $data = trim($_POST['ycs_ID']);
                $mode='edit';
                if(isset($_SESSION['ycs_ID']))
                {
                    $data = trim($_SESSION['ycs_ID']);
                    unset($_SESSION['ycs_ID']);
                    $mode='Confirm';
                }
           // var_dump($data);
                if (!$data) {
                    $this->tpl->set('message', 'Please select any one ID to edit!');
                    $this->tpl->set('label', 'List');
                    $this->tpl->set('content', $this->tpl->fetch('factory/template/form_button_link.php'));
                    break;
                }
                
                //mode of form submit
                $this->tpl->set('mode', $mode);
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);         
                            
                // $sqlsrr = "SELECT  *,$enquiry_tab.PONo,
                //            FROM  $po_master_tab
                //            LEFT JOIN $po_detail_tab ON $po_master_tab.ID=$po_detail_tab.purchaseorder_ID
                //            LEFT JOIN $rawmaterial_table ON  $po_detail_tab.rawmaterial_ID=$rawmaterial_table.ID
                //            LEFT JOIN $supplier_tab  ON $supplier_tab.ID=$po_master_tab.supplier_ID 
                //            LEFT JOIN $state_tab  ON $state_tab.ID=$supplier_tab.State_ID 
                //            LEFT JOIN $unit_table  ON $unit_table.ID=$po_detail_tab.unit_ID 
                //            WHERE $po_master_tab.ID = '$data' 
                //            ORDER BY $po_detail_tab.ID ASC";


               $sqlsrr="SELECT * FROM $inventory_transfer_tab,$inventory_transfer_detail_tab
                WHERE  $inventory_transfer_tab.ID = $inventory_transfer_detail_tab.inventory_transfer_ID
                AND $inventory_transfer_tab.ID = $data";         

                $indent_data = $dbutil->getSqlData($sqlsrr);               
                $indentsel_data  = $stmt->fetchAll();	
                $this->tpl->set('indent_data', $indentsel_data);
            
                //edit option     
                $this->tpl->set('message', 'You can edit Stock Return form');
                $this->tpl->set('page_header', 'Store');
                $this->tpl->set('FmData', $indent_data); 
                
                $this->tpl->set('content', $this->tpl->fetch('factory/form/inventory_transfer_form.php'));                    
                break;
            
            case 'editsubmit':             
                $data = trim($_POST['ycs_ID']);
                
                //mode of form submit
                $this->tpl->set('mode', 'edit');
                //set id to edit $ycs_ID
                $this->tpl->set('ycs_ID', $data);

                //Post data
                include_once 'util/genUtil.php';
                $util = new GenUtil();
                $form_post_data = $util->arrFltr($_POST);

                //        echo '<pre>';
                //    print_r($form_post_data); die;
                
                // $sqldet_del = "DELETE FROM $po_detail_tab WHERE purchaseorder_ID=$data";
                // $stmt = $this->db->prepare($sqldet_del);
                // $stmt->execute();   
                        
                        try{
                            
                                                    
                    
        
                        
                        $store = $form_post_data['store'];
                        $from_warehous = $form_post_data['from_warehouse'];
                        $to_warehouse = $form_post_data['to_warehouse'];
                        // $workorder_no= $form_post_data['workorder_no'];
                        // $process_name= $form_post_data['process_name'];  
                        // $product_number= $form_post_data['product_number'];
                        // $process= $form_post_data['process'];
                        // $product_size= $form_post_data['product_size'];
                        // $thickness= $form_post_data['thickness'];
                        // $color= $form_post_data['color'];
                        // $design= $form_post_data['design']; 
                        // $quantity= $form_post_data['quantity']; 
                        // $completed_on= $form_post_data['completed_on']; 
                        // $lay_up_sequence= $form_post_data['lay_up_sequence'];   
                        // $details= $form_post_data['details'];  
                        // $remarks= $form_post_data['remarks'];  
                        // $created_by= $form_post_data['created_by']; 


                        $sql2 = "UPDATE $inventory_transfer_tab set

                        store='$store',
                        po_no='$from_warehous',
                        work_order_no='$to_warehouse'
                          

                         WHERE ID=$data";	
                        
                        $stmt = $this->db->prepare($sql2);   
                        $stmt->execute();

                        $sql3 = "DELETE FROM $inventory_transfer_detail_tab WHERE inventory_transfer_ID=$data";
					     $stmt3 = $this->db->prepare($sql3);

                    if($stmt3->execute()){
                    
                    FOR ($entry_count = 1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {                         
                            $item_name =$form_post_data['item_name_' . $entry_count]; 
                            $batch =$form_post_data['batch_' . $entry_count]; 
                            $availabel_stock =$form_post_data['availabel_stock_' . $entry_count];
                            $transfer_quantity =$form_post_data['transfer_quantity_' . $entry_count];								
                            $unit =$form_post_data['unit_' . $entry_count];
                           
                            if(!empty($item_name) && !empty($batch)){
                          

                                    $vals = "'" . $data . "'," .
                                   
                                    "'" . $item_name . "'," .
                                    "'" . $batch . "'," .
                                    "'" . $availabel_stock . "'," .
                                    "'" . $transfer_quantity . "'," .
                                    "'" . $unit . "'" ;
                                    

                            $sql2 = "INSERT INTO $inventory_transfer_detail_tab
                                    ( 

                                        `inventory_transfer_ID`, 
                                        `item_name`,
                                        `batch`,
                                        `availabel_stock`,
                                        `transfer_quantity`,
                                        `unit`
                                        
                                    ) 
                            VALUES ($vals)";        

                            $stmt = $this->db->prepare($sql2);
                            $stmt->execute();               
                        }
                        }  

                        
                    }
                                    
                        $this->tpl->set('message', 'Inventory Transfer form edited successfully!');   
                        header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/inventorytransfer');
                       
                        } catch (Exception $exc) {
                         //edit failed option
                        $this->tpl->set('message', 'Failed to edit, try again!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/inventory_transfer_form.php'));
                        }

                break;
                
            case 'addsubmit':
                
                if (isset($crud_string)) {
                     
                    $form_post_data = $dbutil->arrFltr($_POST);
                    // $dispatch_date=!empty($form_post_data['invoice_date_'])?date("Y-m-d", strtotime($form_post_data['DispatchDate'])):'';
                    //  $completed_on=!empty($form_post_data['completed_on'])?date("Y-m-d", strtotime($form_post_data['completed_on'])):'';
                    // "'" . $dispatch_date . "'," .
                    // $purchase_indentno=$form_post_data['purchaseindent_ID'];
                //     echo '<pre>';
                //    print_r($form_post_data); die;
                    
                            $val =  "'" . $form_post_data['store'] . "'," .                                  
                                    "'" . $form_post_data['from_warehouse'] . "'," .
                                    "'" . $form_post_data['to_warehouse'] . "'," .
                                    // "'" . $form_post_data['workorder_no'] . "'," .
                                    // "'" . $form_post_data['process_name'] . "'," .
                                    // "'" . $form_post_data['product_number'] . "'," .
                                    // "'" . $form_post_data['process'] . "'," .
                                    // "'" . $form_post_data['product_size'] . "'," .
                                    // "'" . $form_post_data['thickness'] . "'," .
                                    // "'" . $form_post_data['color'] . "'," .
                                    // "'" . $form_post_data['design'] . "'," .
                                    // "'" . $form_post_data['quantity'] . "'," .
                                    // "'" . $form_post_data['completed_on'] . "'," .
                                    // "'" . $form_post_data['lay_up_sequence'] . "'," .
                                    // "'" . $form_post_data['details'] . "'," .
                                    // "'" . $form_post_data['remarks'] . "'," .
                                    // "'" . $form_post_data['created_by'] . "'," .
                                    "'" .  $this->ses->get('user')['entity_ID'] . "'," .
                                    "'" .  $this->ses->get('user')['ID'] . "'";

                       $sql = "INSERT INTO `" . $this->crg->get('table_prefix') . "inventory_transfer`
                                        ( 
                                        `store`,
                                        `from_warehouse`,
                                        `to_warehouse`,                                      
                                        `entity_ID`,
                                        `users_ID`
                                        ) 
                                VALUES ( $val )";
                                $stmt = $this->db->prepare($sql);      
                    if ($stmt->execute()) { 
                    
                    $lastInsertedID = $this->db->lastInsertId();  
                  FOR ($entry_count=1; $entry_count <= $form_post_data['maxCount']; $entry_count++) {

                            //  $invoice_date=!empty($form_post_data['completed_on_'. $entry_count])?date("Y-m-d", strtotime($form_post_data['completed_on_'. $entry_count])):'';
                            $item_name =$form_post_data['item_name_' . $entry_count]; 
                            $batch =$form_post_data['batch_' . $entry_count]; 
                            $availabel_stock =$form_post_data['availabel_stock_' . $entry_count];
                            $transfer_quantity =$form_post_data['transfer_quantity_' . $entry_count];								
                            $unit =$form_post_data['unit_' . $entry_count];
                            // $total_qty_retn =$form_post_data['total_qty_retn_' . $entry_count];
                            // $qty_return =$form_post_data['qty_return_' . $entry_count];
                            // $costunit =$form_post_data['cost_unit_' . $entry_count];
                            // $total =$form_post_data['total_' . $entry_count];
                            // $supplier =$form_post_data['supplier_invoice_no_' . $entry_count];
                            // $invoice =$form_post_data['invoice_date_' . $entry_count];
                            
                            
                        
                            
                           
                            
                            $vals = "'" . $lastInsertedID . "'," .
                                    "'" . $item_name . "'," .
                                    "'" . $batch . "'," .
                                    "'" . $availabel_stock . "'," .
                                    "'" . $transfer_quantity . "',".
                                    "'" . $unit . "'" ;
                                    // "'" . $total_qty_retn . "'," .
                                    // "'" . $qty_return . "'" ;
                                    // "'" . $costunit . "'," .
                                    // "'" . $total . "'," .
                                    // "'" . $supplier . "'," .
                                    // "'" . $invoice_date . "'" ;   
                                         $sql2 = "INSERT INTO $inventory_transfer_detail_tab
                                    ( 
                                        `inventory_transfer_ID`, 
                                        `item_name`,
                                        `batch`,
                                        `availabel_stock`,
                                        `transfer_quantity`,
                                        `unit`
                                       
                                       
                                    ) 
                            VALUES ($vals)";
                            $stmt = $this->db->prepare($sql2);
                        $stmt->execute();                           
                       
                        
                           
                        } 
                        
                        
                      
                    }
                                                       
                    $this->tpl->set('mode', 'add');
                    $this->tpl->set('message', '- Success -');
                    header('Location:' . $this->crg->get('route')['base_path'] . '/store/cst/inventorytransfer');
                 } else {
                        //edit option
                        //if submit failed to insert form
                        $this->tpl->set('message', 'Failed to submit!');
                        $this->tpl->set('FmData', $form_post_data);
                        $this->tpl->set('content', $this->tpl->fetch('factory/form/inventory_transfer_form.php'));
                 }
                 
                break;

            case 'add':
                $this->tpl->set('mode', 'add');
                $this->tpl->set('page_header', 'Store');
                $MaterialNo=$dbutil->keyGeneration('materialinward','MNO','','MaterialNo');
                $this->tpl->set('MaterialNo', $MaterialNo);
                $this->tpl->set('content', $this->tpl->fetch('factory/form/inventory_transfer_form.php'));
                break;

            default:
                /*
                 * List form
                 */
                 
                ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
     $colArr = array(
            // "$inventory_transfer_tab.ID",
            // "$inventory_transfer_tab.store",
            // "$inventory_transfer_tab.from_warehouse",
            // "$inventory_transfer_tab.to_warehouse"
            "$inventory_transfer_tab.ID", 
            "$inventory_transfer_tab.store",
            "$inventory_transfer_tab.from_warehouse",
            "$inventory_transfer_tab.to_warehouse",
            "$inventory_transfer_tab.date"
            
            // "$po_master_tab.ID"

        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

            if (strpos($colNames, 'DATE') !== false) {
                list($colNames,$x) = $dbutil->dateFilterFormat($colNames);                    
            }else {
                $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);        		    
            }

              if ('' != $x) {
               $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
       IF (count($wsarr) >= 1) {
            $whereString = ' AND '. implode(' AND ', $wsarr);
        }
       } else {
         $whereString ="ORDER BY $inventory_transfer_tab.ID DESC";
       }
       
    $sql = "SELECT "
                . implode(',',$colArr)
                . " FROM $inventory_transfer_tab "
                . " WHERE "
                . " $inventory_transfer_tab.entity_ID = $entityID"
                . " $whereString"; 
        
     

            $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
        /*
         * SET DATA TO TEMPLATE
                    */
       $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
     
     
       $this->tpl->set('table_columns_label_arr', array('ID','Reference No.','From Warehouse','To Warehouse','Date'));
        // $this->tpl->set('table_columns_label_arr', array('ID','store','stockreturn_no','po_no'));
        
        /*
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
        // $this->tpl->set('dcpdf','Generate Pdf');            
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
        //////////////////////close//////////////////////////////////////  
                 
                include_once $this->tpl->path . '/factory/form/inventory_transfer_crud_form.php';
                $cus_form_data = Form_Elements::data($this->crg);
                include_once 'util/crud3_1.php';
                new Crud3($this->crg, $cus_form_data);
                break;
        }

    ///////////////Use different template////////////////////
    // $this->tpl->set('master_layout', 'layout_chart.php'); 
    $this->tpl->set('master_layout', 'layout_datepicker.php');
    ///////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then /////
    ///////////////////////////////////////////////////////////////////
 } else {
         if ($this->ses->get('user')['ID']) {
             $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
         } else {
             header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
         }
     }
}

/////////////////////////////////////////////////////////
//////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
///////////////////////////////// stock Transfer List //////////

// function stocktransferlist() {
//     if ($this->crg->get('wp') || $this->crg->get('rp')) {
// //////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////access condition applied///////////////////////////
// //////////////////////////////////////////////////////////////////////////////// 
      
//        include_once 'util/DBUTIL.php';
//        $dbutil = new DBUTIL($this->crg);
         
//          $entityID = $this->ses->get('user')['entity_ID'];
//          $userID = $this->ses->get('user')['ID'];
        
        
//        $inventory_trans_tab = $this->crg->get('table_prefix') . 'inventory_transfer';
              
      

//         ////////////////////start//////////////////////////////////////////////
                
//        //bUILD SQL 
//         $whereString = '';
        
//         $colArr = array(
//             "$inventory_trans_tab.ID", 
//             "$inventory_trans_tab.store",
//             "$inventory_trans_tab.from_warehouse",
//             "$inventory_trans_tab.to_warehouse",
//             "$inventory_trans_tab.date"
           
//         );
        
//         $this->tpl->set('FmData', $_POST);
//         foreach($_POST as $k=>$v){
//             if(strpos($k,'^')){
//                 unset($_POST[$k]);
//             }
//             $_POST[str_replace('^','_',$k)] = $v;
//         }
//         $PD=$_POST;
//         if($_POST['list']!=''){
//             $this->tpl->set('FmData', NULL);
//             $PD=NULL;
//         }

//         IF (count($PD) >= 2) {
//             $wsarr = array();
//             foreach ($colArr as $colNames) {

//        if (strpos($colNames, 'Date') !== false) {
//             list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
//         } else {
//             $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
//         }

//                 if ('' != $x) {
//                     $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
//                 }
//             }
            
//           IF (count($wsarr) >= 1) {
//              $whereString = ' AND '. implode(' AND ', $wsarr);
//           }
//         }
        
//         $orderBy ="ORDER BY $inventory_trans_tab.ID DESC";
        
//      $sql = "SELECT "
//              . implode(',',$colArr)
//              . " FROM $inventory_trans_tab "
//              . " WHERE "
//              . " $inventory_trans_tab.entity_ID=$entityID "
//              . " $whereString "
//              . " $orderBy";
     
//         $results_per_page = 50;     
        
//             if(isset($PD['pageno'])){$page=$PD['pageno'];}
//             else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
//             else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
//             else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
//             else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
//             else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
//             else{$page=1;} 
     
//         /*
//          * SET DATA TO TEMPLATE
//          */
//         $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
//         /*
//          * set table label
//          */
//         $this->tpl->set('table_columns_label_arr', array('ID','Reference No.','From Warehouse','To Warehouse','Date'));
        
//         /*,;;
//          * selectColArr for filter form
//          */
        
//         $this->tpl->set('selectColArr',$colArr);
                    
//         /*
//          * set pagination template
//          */
//         $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table.php');
               
//         //////////////////////close//////////////////////////////////////  
      
//          include_once $this->tpl->path .'/factory/form/stockreturn_crud_form.php';
        
        
//         $cus_form_data = Form_Elements::data($this->crg);
//         include_once 'util/crud3_1.php';
//         new Crud3($this->crg, $cus_form_data);
//         $this->tpl->set('master_layout', 'layout_datepicker.php'); 
//          //if crud is delivered at different point a template
//         //Then  call that template and set to content
       
//        ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
//     //////////////////////////////////////////////////////////////////////////////////
//     //////////////////////////////on access condition failed then ///////////////////////////
//     ////////////////////////////////////////////////////////////////////////////////            
//     } else {
//         if ($this->ses->get('user')['ID']) {
//             $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
//         } else {
//             header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
//         }
//     }
// } 


///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
/////////////////////   stock transactin report


function stacktransreport() {
    if ($this->crg->get('wp') || $this->crg->get('rp')) {
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////access condition applied///////////////////////////
//////////////////////////////////////////////////////////////////////////////// 
      
       include_once 'util/DBUTIL.php';
       $dbutil = new DBUTIL($this->crg);
         
         $entityID = $this->ses->get('user')['entity_ID'];
         $userID = $this->ses->get('user')['ID'];
        
        
       $stock_trans = $this->crg->get('table_prefix') . 'stock_trans';
              
      

        ////////////////////start//////////////////////////////////////////////
                
       //bUILD SQL 
        $whereString = '';
        
        $colArr = array(
            "$stock_trans.ID", 
            "$stock_trans.date",
            "$stock_trans.raw_material_typ",
            "$stock_trans.raw_material_name",
            "$stock_trans.batch_no",
            "$stock_trans.stockin",
            "$stock_trans.stockout",
           
            "$stock_trans.available_qty"
           
        );
        
        $this->tpl->set('FmData', $_POST);
        foreach($_POST as $k=>$v){
            if(strpos($k,'^')){
                unset($_POST[$k]);
            }
            $_POST[str_replace('^','_',$k)] = $v;
        }
        $PD=$_POST;
        if($_POST['list']!=''){
            $this->tpl->set('FmData', NULL);
            $PD=NULL;
        }

        IF (count($PD) >= 2) {
            $wsarr = array();
            foreach ($colArr as $colNames) {

       if (strpos($colNames, 'Date') !== false) {
            list($colNames,$x) = $dbutil->dateFilterFormat($colNames);
        } else {
            $x = $dbutil->__mdsf($PD[str_replace('.','_',$colNames)]);
        }

                if ('' != $x) {
                    $wsarr[] = $colNames . " LIKE '%" . $x . "%'";
                }
            }
            
          IF (count($wsarr) >= 1) {
             $whereString = ' AND '. implode(' AND ', $wsarr);
          }
        }
        
        $orderBy ="ORDER BY $stock_trans.ID DESC";
        
     $sql = "SELECT "
             . implode(',',$colArr)
             . " FROM $stock_trans "
             . " WHERE "
             . " $stock_trans.entity_ID=$entityID "
             . " $whereString "
             . " $orderBy";
     
        $results_per_page = 50;     
        
            if(isset($PD['pageno'])){$page=$PD['pageno'];}
            else if(isset($PD['pagenof'])){$page=$PD['pagenofirst'];}
            else if(isset($PD['pagenop'])){$page=$PD['pagenoprev'];}
            else if(isset($PD['pagenon'])){$page=$PD['pagenonext'];}
            else if(isset($PD['pagenol'])){$page=$PD['pagenolast'];}
            else if(isset($PD['pagenog'])){$page=$PD['pagenogo'];}
            else{$page=1;} 
     
        /*
         * SET DATA TO TEMPLATE
         */
        $this->tpl->set('sql_data_rows', $dbutil->setPaginationList($sql,$page,$results_per_page,$wsarr));
        /*
         * set table label
         */
        $this->tpl->set('table_columns_label_arr', array('ID','date','Raw Material Name','Raw Material Name','Batch No.','Stockin','stockout','availabel Qty'));
        
        /*,;;
         * selectColArr for filter form
         */
        
        $this->tpl->set('selectColArr',$colArr);
                    
        /*
         * set pagination template
         */
        $this->crg->set('paginationListTemplate','factory/template/sql_based_crud_paginated_table_copy.php');
               
        //////////////////////close//////////////////////////////////////  
      
         include_once $this->tpl->path .'/factory/form/stocktransferReport_crud_form.php';
        
        
        $cus_form_data = Form_Elements::data($this->crg);
        include_once 'util/crud3_1.php';
        new Crud3($this->crg, $cus_form_data);
        // $this->tpl->set('master_layout', 'layout_chart.php'); 
        // $this->tpl->set('master_layout', 'layout_chart.php'); 
        $this->tpl->set('master_layout', 'layout_datepicker.php');
         //if crud is delivered at different point a template
        //Then  call that template and set to content
       
       ////$this->tpl->set('content', $this->tpl->fetch('modules/customer/manage_customer.php'));
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////on access condition failed then ///////////////////////////
    ////////////////////////////////////////////////////////////////////////////////            
    } else {
        if ($this->ses->get('user')['ID']) {
            $this->tpl->set('content', $this->tpl->fetch('modules/user/acess_failed_message.php'));
        } else {
            header('Location:' . $this->crg->get('route')['base_path'] . '/user/auth/login');
        }
    }
} 


}
