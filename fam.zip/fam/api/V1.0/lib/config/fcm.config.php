<?php

/**
 * @copyright Copyright (c) 2014-2016 www.whyceeyes.com
 */
return [
    'FireBaseApiKey' => 'AIzaSyBxDTHGpE_Hwrop4OCY3REUcdv0N107Cwc',   
    'apiUrl' => 'https://fcm.googleapis.com/fcm/send',
    'cloudMsgServerKey' =>'AAAAdsSKaWw:APA91bEsmXakKqSibLXWfAhiuGlemmKWCNcVhdG_Y3EJOziS-yJQzOzoTHJAPM-fhkMHCmn6ito-Glbrr46rJeoHh44GSgPwxSAgcq3LrBKV1GMkB1MGVnPV2bR1vWJweIc68Kr_zgCf',
    'senderID'=>'510103546220'
];