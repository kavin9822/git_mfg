<?php
return ['login', 'logout', 'forgetPwd'];