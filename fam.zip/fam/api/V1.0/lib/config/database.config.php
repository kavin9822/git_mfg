<?php
/**
 * @copyright Copyright (c) 2014-2016 www.whyceeyes.com 
 * 
 */

return [
    'database_type' => 'mysql',
    'database_name' => 'whyceffy_fam',
    'server' => 'localhost',
    'username' => 'whyceffy_gbs',
    'password' => '$3}rrS.wBVJV',
    'charset' => 'utf8',
    'port' => 3306,
    'prefix' => 'ycias_',
    'option' => [
        PDO::ATTR_CASE => PDO::CASE_NATURAL,
    ]
];
